"""Builds every model in models/ for BAD INFLUENCE (a Paper-look film) with Blender
(run inside Blender, or with the bpy module):  blender -b --python tools/make_props.py
Flat, side-on shapes: each is a 2D outline pushed into depth, so it reads like an
ink drawing from the Sketch Stage's side camera. Sizes in metres, origin at the bottom
centre, front = -Y (towards the camera). Colours are a little brighter than wanted:
Scene Builder mutes package models in the Flat sketch look.
"""
import math
import os

import bpy
import bmesh  # after bpy: the bpy module provides it

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "models")


def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def mat(name, color, emit=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*color, 1)
    b.inputs["Roughness"].default_value = 0.8
    if emit:
        b.inputs["Emission Color"].default_value = (*color, 1)
        b.inputs["Emission Strength"].default_value = emit
    return m


def slab(name, outline, y0, y1, material):
    """A 2D outline [(x, z), …] (counter-clockwise, seen from the front) pushed from y0 to y1."""
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    front = [bm.verts.new((x, y0, z)) for x, z in outline]
    back = [bm.verts.new((x, y1, z)) for x, z in outline]
    bm.faces.new(front)
    bm.faces.new(list(reversed(back)))
    n = len(outline)
    for i in range(n):
        j = (i + 1) % n
        bm.faces.new([front[i], back[i], back[j], front[j]])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(obj)
    mesh.materials.append(material)
    return obj


def disc(name, radius, centre, y, material, verts=48):
    pts = [(centre[0] + radius * math.cos(a), centre[1] + radius * math.sin(a))
           for a in [i / verts * math.tau for i in range(verts)]]
    return slab(name, pts, y, y + 0.05, material)


def export(name):
    bpy.ops.export_scene.gltf(filepath=os.path.join(OUT, name + ".glb"), export_format="GLB")
    print("built", name)







def donut():
    """A pink-iced donut, standing up so the side camera sees the ring. It is built
    sitting on a desk top (0.775 m up) although its origin is on the ground, so it can
    be placed anywhere along a desk: donut at (0.85, 0)."""
    lift = 0.775
    reset()
    dough = mat("dough", (0.85, 0.6, 0.35))
    icing = mat("icing", (1.0, 0.55, 0.75))
    disc("dough", 0.09, (0, 0.1 + lift), -0.02, dough, verts=32)
    disc("icing", 0.075, (0, 0.105 + lift), -0.025, icing, verts=32)
    disc("hole", 0.03, (0, 0.1 + lift), -0.03, mat("hole", (0.93, 0.89, 0.79)), verts=24)
    for i in range(6):
        a = i / 6 * math.tau
        slab("sprinkle%d" % i, [(0.055 * math.cos(a) - 0.008, lift + 0.1 + 0.055 * math.sin(a)), (0.055 * math.cos(a) + 0.008, lift + 0.1 + 0.055 * math.sin(a)),
                                (0.055 * math.cos(a) + 0.008, lift + 0.1 + 0.055 * math.sin(a) + 0.006), (0.055 * math.cos(a) - 0.008, lift + 0.1 + 0.055 * math.sin(a) + 0.006)],
             -0.035, -0.03, mat("sprinkle%d" % i, [(0.3, 0.6, 1.0), (1.0, 0.9, 0.2), (0.4, 0.9, 0.5)][i % 3]))
    export("donut")


def cake():
    """A small birthday cake with three candles."""
    reset()
    slab("cake", [(-0.16, 0), (0.16, 0), (0.16, 0.14), (-0.16, 0.14)], -0.16, 0.16, mat("cake", (0.98, 0.9, 0.82)))
    slab("icing", [(-0.165, 0.11), (0.165, 0.11), (0.165, 0.15), (-0.165, 0.15)], -0.17, 0.17, mat("cakeicing", (0.95, 0.5, 0.65)))
    for i, x in enumerate((-0.07, 0.0, 0.07)):
        slab("candle%d" % i, [(x - 0.008, 0.15), (x + 0.008, 0.15), (x + 0.008, 0.23), (x - 0.008, 0.23)], -0.01, 0.01, mat("candle%d" % i, (0.4, 0.7, 1.0)))
        disc("flame%d" % i, 0.012, (x, 0.245), -0.012, mat("flame", (1.0, 0.75, 0.2), emit=1.5), verts=12)
    export("cake")


def bunting():
    """Party bunting and fairy lights strung across the room, 6 m wide, 2.4 m up."""
    reset()
    string = mat("string", (0.3, 0.28, 0.26))
    colors = [(0.95, 0.4, 0.45), (0.98, 0.8, 0.3), (0.4, 0.75, 0.95), (0.5, 0.85, 0.55)]
    pts = []
    for i in range(61):
        x = -3 + i * 0.1
        pts.append((x, 2.6 - 0.35 * (1 - (x / 3) ** 2)))
    upper = pts + [(x, z + 0.015) for x, z in reversed(pts)]
    slab("string", upper, -0.01, 0.01, string)
    for i in range(12):
        x = -2.75 + i * 0.5
        z = 2.6 - 0.35 * (1 - (x / 3) ** 2)
        slab("flag%d" % i, [(x - 0.14, z), (x + 0.14, z), (x, z - 0.3)], -0.015, 0.015, mat("flag%d" % i, colors[i % 4]))
    export("bunting")


def bench():
    """A park bench, seat 0.45 m, 1.6 m long."""
    reset()
    wood = mat("benchwood", (0.6, 0.42, 0.28))
    metal = mat("benchmetal", (0.3, 0.3, 0.32))
    slab("seat", [(-0.8, 0.42), (0.8, 0.42), (0.8, 0.47), (-0.8, 0.47)], -0.2, 0.2, wood)
    slab("back", [(-0.8, 0.6), (0.8, 0.6), (0.8, 0.85), (-0.8, 0.85)], 0.18, 0.22, wood)
    for x in (-0.7, 0.7):
        slab("leg%.1f" % x, [(x - 0.03, 0), (x + 0.03, 0), (x + 0.03, 0.85), (x - 0.03, 0.85)], 0.15, 0.22, metal)
        slab("legf%.1f" % x, [(x - 0.03, 0), (x + 0.03, 0), (x + 0.03, 0.45), (x - 0.03, 0.45)], -0.2, -0.15, metal)
    export("park_bench")


def hq_sign():
    """The board on the wall of Temptation HQ: a big red arrow pointing down."""
    reset()
    slab("board", [(-0.9, 1.4), (0.9, 1.4), (0.9, 2.5), (-0.9, 2.5)], 0.0, 0.05, mat("hqboard", (0.25, 0.22, 0.22)))
    slab("arrow", [(-0.12, 2.35), (0.12, 2.35), (0.12, 1.85), (0.3, 1.85), (0.0, 1.5), (-0.3, 1.85), (-0.12, 1.85)], -0.01, 0.0,
         mat("hqarrow", (0.9, 0.2, 0.2)))
    export("hq_sign")


def tree():
    reset()
    bark = mat("bark", (0.45, 0.36, 0.3))
    leaf = mat("leaf", (0.4, 0.62, 0.4))
    slab("trunk", [(-0.12, 0), (0.12, 0), (0.08, 1.8), (-0.08, 1.8)], -0.08, 0.08, bark)
    for i, (r, cx, cz) in enumerate([(0.9, 0, 2.4), (0.7, -0.6, 2.0), (0.7, 0.65, 2.1)]):
        disc("leaf%d" % i, r, (cx, cz), 0.1 + i * 0.01, leaf)
    export("tree")


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    donut()
    cake()
    bunting()
    bench()
    hq_sign()
    tree()
