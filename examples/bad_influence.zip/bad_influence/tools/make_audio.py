"""Original music and sound effects for BAD INFLUENCE, synthesised from scratch
(no samples, no recordings). Usage:
    python tools/make_audio.py
Needs numpy, scipy and ffmpeg (for .ogg). Music -> music/*.ogg, effects -> sfx/*.wav.

A comedy score: sneaky plucked strings and a grumpy tuba for Temptation HQ and every
failed temptation, a brisk march when Ellie jumps out of bed, a chase for the run, a
silly lounge tune for the donut, a quiet lonely piano on her birthday that warms when
Smudge finds the right temptation, and a bouncy party - interrupted by the Boss.
Cue lengths are at the bottom.
"""
import os
import subprocess

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

RATE = 44100
RNG = np.random.default_rng(13)
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")


# --- Building blocks ---------------------------------------------------------------

def t_axis(seconds):
    return np.arange(int(seconds * RATE)) / RATE


def lowpass(x, f, order=2):
    return sosfilt(butter(order, f, "low", fs=RATE, output="sos"), x)


def highpass(x, f, order=2):
    return sosfilt(butter(order, f, "high", fs=RATE, output="sos"), x)


def hz(name):
    names = {"C": -9, "C#": -8, "D": -7, "D#": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "A": 0, "A#": 1, "B": 2}
    return 440.0 * 2 ** ((names[name[:-1]] + (int(name[-1]) - 4) * 12) / 12)


def place(track, sound, at):
    i = int(at * RATE)
    if i >= len(track):
        return
    end = min(len(track), i + len(sound))
    track[i:end] += sound[: end - i]


def reverb(x, amount=0.3):
    out = x.copy()
    for delay, gain in [(0.031, 0.6), (0.043, 0.5), (0.059, 0.45), (0.083, 0.4), (0.113, 0.35), (0.157, 0.3)]:
        d = int(delay * RATE)
        y = np.zeros_like(x)
        y[d:] = x[:-d]
        for _ in range(5):
            y[d:] += y[:-d] * gain * 0.55
        out += y * amount * gain
    return out


def fade(x, fade_in=0.05, fade_out=2.0):
    n = len(x)
    e = np.ones(n)
    a = int(fade_in * RATE)
    b = int(fade_out * RATE)
    if a:
        e[:a] = np.linspace(0, 1, a)
    if b:
        e[-b:] *= np.linspace(1, 0, b) ** 1.5
    return x * e


def normalise(x, peak=0.85):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak


def piano(freq, seconds=2.5, velocity=1.0):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for k, amp in enumerate([1.0, 0.45, 0.25, 0.12, 0.08, 0.04], start=1):
        f = freq * k * (1 + 0.0004 * k * k)
        out += amp * np.sin(2 * np.pi * f * t) * np.exp(-t * (1.2 + 0.9 * k))
    hammer = np.exp(-t * 60) * RNG.standard_normal(len(t)) * 0.02
    attack = np.minimum(1, t / 0.004)
    return (out + hammer) * attack * velocity


def pad(freqs, seconds, brightness=900, detune=0.003):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for f in freqs:
        for d in (-detune, 0, detune):
            phase = 2 * np.pi * f * (1 + d) * t
            out += sum(np.sin(k * phase) / k for k in range(1, 8))
    out = lowpass(out, brightness, 2)
    swell = np.minimum(1, t / 1.5) * np.minimum(1, (seconds - t) / 1.5)
    return out * swell / (len(freqs) * 3)


def strings(freq, seconds, attack=0.08):
    t = t_axis(seconds)
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t)
    phase = 2 * np.pi * freq * np.cumsum(vib) / RATE
    out = sum(np.sin(k * phase) * (0.7 ** k) for k in range(1, 9))
    env = np.minimum(1, t / attack) * np.minimum(1, (seconds - t) / 0.05)
    return lowpass(out, 2600) * env


def kick(seconds=0.6, depth=1.0):
    t = t_axis(seconds)
    f = 45 + 110 * np.exp(-t * 28)
    body = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 7)
    click = RNG.standard_normal(len(t)) * np.exp(-t * 180) * 0.15
    return (body + click) * depth


def taiko(seconds=1.2):
    t = t_axis(seconds)
    f = 62 + 50 * np.exp(-t * 12)
    body = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 3.2)
    skin = lowpass(RNG.standard_normal(len(t)), 700) * np.exp(-t * 14) * 0.5
    return body + skin


def snare(seconds=0.35):
    t = t_axis(seconds)
    noise = highpass(RNG.standard_normal(len(t)), 1800) * np.exp(-t * 20)
    tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t * 30) * 0.5
    return (noise * 0.6 + tone) * 0.8


def hat(seconds=0.08):
    t = t_axis(seconds)
    return highpass(RNG.standard_normal(len(t)), 7000) * np.exp(-t * 60) * 0.25


def heartbeat():
    beat = np.zeros(int(0.9 * RATE))
    place(beat, kick(0.4, 1.0) * 0.9, 0.0)
    place(beat, kick(0.4, 0.7) * 0.6, 0.22)
    return lowpass(beat, 160)


def to_ogg(name, x):
    os.makedirs(os.path.join(ROOT, "music"), exist_ok=True)
    wav = os.path.join(ROOT, "music", name + ".wav")
    stereo = np.stack([x, np.roll(x, 180)], axis=1)
    wavfile.write(wav, RATE, (normalise(stereo, 0.9) * 32767).astype(np.int16))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "5",
                    os.path.join(ROOT, "music", name + ".ogg")], check=True)
    os.remove(wav)


def to_wav(name, x, peak=0.9):
    os.makedirs(os.path.join(ROOT, "sfx"), exist_ok=True)
    stereo = np.stack([x, np.roll(x, 90)], axis=1)
    wavfile.write(os.path.join(ROOT, "sfx", name + ".wav"), RATE, (normalise(stereo, peak) * 32767).astype(np.int16))




def pluck(freq, seconds=0.6, bright=2500):
    t = t_axis(seconds)
    out = sum(np.sin(2 * np.pi * freq * k * t) * (0.55 ** k) for k in range(1, 6))
    return lowpass(out * np.exp(-t * 7) * np.minimum(1, t / 0.003), bright)


def chord_pad(names, seconds, brightness=900, level=0.5):
    return pad([hz(n) for n in names], seconds, brightness) * level


def music_box(freq, seconds=1.6):
    t = t_axis(seconds)
    out = np.sin(2 * np.pi * freq * t) + 0.35 * np.sin(2 * np.pi * freq * 4.02 * t) * np.exp(-t * 9)
    return out * np.exp(-t * 3.2) * np.minimum(1, t / 0.002)




def pizz(freq, seconds=0.35, level=1.0):
    """A plucked string, short and dry (comedy pizzicato)."""
    t = t_axis(seconds)
    out = sum(np.sin(2 * np.pi * freq * k * t) * (0.5 ** k) for k in range(1, 5))
    return lowpass(out * np.exp(-t * 14) * np.minimum(1, t / 0.002), 3000) * level


def tuba(freq, seconds=0.4, level=1.0):
    """A soft, grumpy low brass note."""
    t = t_axis(seconds)
    phase = 2 * np.pi * freq * t
    out = sum(np.sin(k * phase) / k for k in range(1, 8))
    env = np.minimum(1, t / 0.04) * np.minimum(1, (seconds - t) / 0.08)
    return lowpass(out, 700) * env * level


SNEAK = ["D3", "F3", "G#3", "A3", "D3", "F3", "A3", "G#3"]   # tiptoe tune (D minor, sneaky)


def sneak(out, start, end, step=0.3, level=0.6):
    b = 0
    while start + b * step < end - 0.3:
        tt = start + b * step
        if b % 2 == 0:
            place(out, pizz(hz(SNEAK[(b // 2) % 8]), 0.3, level), tt)
        if b % 4 == 0:
            place(out, tuba(hz(["D2", "A1"][(b // 4) % 2]), 0.35, 0.5 * level), tt)
        b += 1


def fail_sting(out, at, level=0.6):
    """Sad trombone-ish: three falling tuba notes, the last one long."""
    for i, (n, d) in enumerate((("G#2", 0.35), ("G2", 0.35), ("F#2", 1.1))):
        place(out, tuba(hz(n), d, level), at + i * 0.38)


# --- Cues ---------------------------------------------------------------------------

def first_day(seconds, easy_at):
    """Temptation HQ: a sneaky pizzicato tune; a cocky little flourish on "Easy."  """
    out = np.zeros(int((seconds + 3) * RATE))
    sneak(out, 0.0, easy_at)
    for i, n in enumerate(["D4", "F4", "A4", "D5"]):
        place(out, pizz(hz(n), 0.4, 0.8), easy_at + i * 0.12)
    place(out, tuba(hz("D2"), 1.0, 0.5), easy_at + 0.5)
    return fade(reverb(out[: int(seconds * RATE)], 0.25), 0.1, 1.5)


def five_am(seconds, up_at, fail_at):
    """A sly lullaby; when Ellie jumps up, a brisk major march; a fail sting at the door."""
    out = np.zeros(int((seconds + 3) * RATE))
    for i, n in enumerate(["A4", "F4", "D4", "F4", "A4", "G4", "E4", "C4"] * 2):
        at = 0.5 + i * 0.55
        if at > up_at - 0.3:
            break
        place(out, music_box(hz(n)) * 0.3, at)
    beat = 0.25
    for b in range(int((fail_at - up_at) / beat)):
        tt = up_at + b * beat
        place(out, pizz(hz(["C4", "E4", "G4", "C5"][b % 4]), 0.25, 0.6), tt)
        if b % 2 == 0:
            place(out, snare() * 0.25, tt)
        if b % 4 == 0:
            place(out, tuba(hz(["C2", "G1"][(b // 4) % 2]), 0.25, 0.5), tt)
    fail_sting(out, fail_at)
    return fade(reverb(out[: int(seconds * RATE)], 0.25), 0.2, 1.5)


def the_run(seconds, collapse_at):
    """A fast chase; it runs out of breath when Smudge collapses."""
    out = np.zeros(int((seconds + 3) * RATE))
    beat = 0.17
    for b in range(int(collapse_at / beat)):
        tt = b * beat
        place(out, pizz(hz(["E4", "G4", "B4", "G4", "E4", "F#4", "A4", "F#4"][b % 8]), 0.2, 0.55), tt)
        if b % 2 == 0:
            place(out, kick(0.25, 0.5) * 0.35, tt)
        place(out, hat() * 0.5, tt)
    # Out of breath: the tune slows down and droops.
    for i, n in enumerate(["E4", "D4", "C4", "B3", "A3"]):
        place(out, pizz(hz(n), 0.4, 0.5), collapse_at + i * (0.35 + i * 0.12))
    fail_sting(out, seconds - 3.5, 0.5)
    return fade(reverb(out[: int(seconds * RATE)], 0.2), 0.1, 1.2)


def the_donut(seconds, fail_at):
    """A silly, slinky lounge tune for the temptations; a big fail sting on Focus mode."""
    out = np.zeros(int((seconds + 3) * RATE))
    beat = 0.36
    walk = ["F2", "A2", "C3", "D3", "D#3", "D3", "C3", "A2"]
    for b in range(int(fail_at / beat)):
        tt = b * beat
        place(out, tuba(hz(walk[b % 8]), 0.3, 0.55), tt)
        if b % 2 == 1:
            place(out, hat() * 0.6, tt)
        if b % 8 == 0:
            place(out, chord_pad(["F3", "A3", "D#4"], beat * 8, 1500, 0.3), tt)
    fail_sting(out, fail_at, 0.7)
    return fade(reverb(out[: int(seconds * RATE)], 0.3), 0.2, 1.5)


def quiet_part(seconds, warm_at, yes_at):
    """Her birthday, alone: a quiet piano. Warmer when Smudge whispers the right
    temptation; a happy little lift when she says "I'm coming!"  """
    out = np.zeros(int((seconds + 4) * RATE))
    for i, n in enumerate(["E4", "C4", "A3", "C4", "B3", "G3", "A3", "E3", "F3", "A3"]):
        place(out, piano(hz(n), 3.0, 0.38), 0.8 + i * (warm_at - 2.0) / 10)
    place(out, chord_pad(["A2", "E3"], warm_at, 500, 0.3), 0)
    chords = [["F2", "C3", "A3"], ["C3", "G3", "E4"], ["G2", "D3", "B3"]]
    for k, ch in enumerate(chords):
        for i, n in enumerate(ch):
            place(out, piano(hz(n), 3.5, 0.42), warm_at + k * 3.0 + i * 0.1)
            place(out, strings(hz(n), 3.2, 0.7) * 0.03, warm_at + k * 3.0)
    for i, n in enumerate(["C5", "E5", "G5", "C6"]):
        place(out, music_box(hz(n)) * 0.45, yes_at + i * 0.12)
    for i, n in enumerate(["C3", "G3", "C4", "E4"]):
        place(out, piano(hz(n), 4.0, 0.5), yes_at + 0.4 + i * 0.05)
    return fade(reverb(out[: int(seconds * RATE)], 0.45), 0.4, 2.0)


def party(seconds, boss_at, resume_at, chord_at):
    """A bouncy party in C; the Boss arrives with low tuba and a tremolo; the party comes
    back when Smudge dances; a big chord on the title."""
    out = np.zeros(int((seconds + 6) * RATE))
    def groove(start, end, level=1.0):
        beat = 0.25
        b = 0
        while start + b * beat < end - 0.2:
            tt = start + b * beat
            ch = [["C3", "E3", "G3"], ["A2", "C3", "E3"], ["F2", "A2", "C3"], ["G2", "B2", "D3"]][(b // 8) % 4]
            if b % 2 == 0:
                place(out, tuba(hz(ch[0]), 0.22, 0.5 * level), tt)
                place(out, kick(0.3, 0.6) * 0.4 * level, tt)
            else:
                for n in ch:
                    place(out, pizz(hz(n) * 2, 0.2, 0.25 * level), tt)
                place(out, snare() * 0.2 * level, tt)
            place(out, hat() * 0.5 * level, tt)
            if b % 4 == 0:
                place(out, music_box(hz(["E5", "G5", "A5", "G5", "C6", "A5", "G5", "E5"][(b // 4) % 8])) * 0.25 * level, tt)
            b += 1
    groove(0.0, boss_at)
    for k in range(int((resume_at - boss_at) / 0.8)):
        place(out, tuba(hz(["D2", "C#2"][k % 2]), 0.7, 0.6), boss_at + k * 0.8)
    t = t_axis(resume_at - boss_at)
    trem = np.sin(2 * np.pi * hz("D4") * t) * (0.5 + 0.5 * np.sin(2 * np.pi * 9 * t)) * 0.12
    place(out, trem, boss_at)
    groove(resume_at, chord_at, 1.0)
    for i, n in enumerate(["C3", "G3", "C4", "E4", "G4", "C5"]):
        place(out, piano(hz(n), 6.0, 0.55), chord_at + i * 0.05)
        place(out, strings(hz(n), seconds - chord_at, 1.0) * 0.05, chord_at)
    for i, n in enumerate(["C5", "E5", "G5", "C6"]):
        place(out, music_box(hz(n)) * 0.4, chord_at + 0.3 + i * 0.1)
    return fade(reverb(out[: int(seconds * RATE)], 0.3), 0.2, 3.0)


if __name__ == "__main__":
    # Cue lengths fit the scene windows of film.script (start -> next cue).
    to_ogg("first_day", first_day(17.5, 14.6))            # 0.0   -> 17.2   flourish on "Easy." (~14.6)
    to_ogg("five_am", five_am(19.6, 5.2, 15.3))           # 17.2  -> 36.5   march when she jumps up (~22.4), fail at the door (~32.5)
    to_ogg("the_run", the_run(11.0, 3.4))                 # 36.5  -> 47.2   Smudge collapses (~39.9)
    to_ogg("the_donut", the_donut(22.0, 17.3))            # 47.2  -> 68.9   fail on Focus mode (~64.5)
    to_ogg("quiet_part", quiet_part(36.7, 20.4, 30.6))    # 68.9  -> 105.3  warm at "Skip the work tonight" (~89.3), lift on "I'm coming!" (~99.5)
    to_ogg("party", party(56.8, 26.0, 37.7, 51.3))        # 105.3 -> end    the Boss (~131.3), party again (~143), chord on the title (~156.6)
    print("made music/*.ogg")
