BAD INFLUENCE  (about 2 min 40 s)
An original Scene Builder comedy in the Paper look (ink on warm paper).

Logline: it's Smudge's first day at Temptation HQ. He's a small shadow with a pink glow,
and the Boss gives him one job: make his human, Ellie, skip ONE thing. But Ellie is the
most disciplined person alive. Snooze? She's up at 5:00. Skip the run? She runs faster.
A donut? Focus mode. Then, on her birthday, Smudge sees that Ellie is alone with her
work - and finds the one temptation that works.

HOW TO WATCH
  Needs Scene Builder 1.10 or newer (the Paper look is new in 1.10).
  Script -> Open... -> bad_influence.zip -> Build Film -> Watch.
  No voices: the shadows talk in whispers that float next to their heads (pink for
  Smudge, red for the Boss), people talk in subtitles.

CHAPTERS
    0:00  First day        Temptation HQ. "Your human: Ellie. Make her skip ONE thing." - "Easy."
    0:17  5:00 AM          "Shhh... five more minutes..." - the alarm, and she's already up.
                           "Okay. Skip the run. It's cold outside." - door slams.
    0:36  The run          Smudge chases her through the park and collapses. "...I'll catch her at breakfast."
    0:47  The donut        "Psst. Donut. Pink icing." - no. "FINE. Phone. Funny cats." - Focus mode.
                           "WHO ARE YOU?"   TEMPTATIONS THAT WORKED: 0 (of 47)
    1:09  The quiet part   8:40 PM. Her birthday. "Party at mine. Come?" - "I have work... I always have work."
                           Smudge: "Hey. Skip the work tonight." - "I'm coming!"   1
    1:45  The party        "You CAME!" Dancing. The Boss: "You tempted her... to be HAPPY?"
                           "She skipped one thing. Like you said." - "YOU'RE FIRED." - "Best day ever."
    2:31  End card         "Not every voice in your head wants to ruin you. Some just want you to live a little."

CAST
  Smudge = shadow (small, pink glow)       Boss = shadow (big, red glow)
  Ellie  = sketch person (coral)           Maya = her sister (blue)       Sam = a friend (green)

THE STAGE (Sketch Stage, left to right): Temptation HQ (x -16), Ellie's flat (x 0),
the park (x 16), Maya's flat (x 30).

FILES
  film.script            the film (STYLE: paper, CAMERA: manual)
  models/*.glb           donut, birthday cake, bunting, park bench, HQ board, tree
                         (tools/make_props.py); bed and headboard (from The Climb sketch)
  music/*.ogg            6 original comedy cues: first_day, five_am, the_run, the_donut,
                         quiet_part, party (tools/make_audio.py)
  sfx/*.wav              buzz, tap, whoosh, pop (Just One More); alarm (The Climb); door (103 Days)
  storyboard.png         frames from a test build

Every model, note and sound was made from scratch by the tools. Story, characters and
lines are original.
