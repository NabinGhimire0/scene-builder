"""Original score and ambience for "The Lantern, Part Two", synthesised from scratch.
Usage:
  python make_lantern2_audio.py <film folder> <length> <scene2> <scene3> <scene4> <release> <ending>
Times are seconds from the start of the film:
  scene2/3/4 = scene starts, release = when the first lantern rises, ending = final wide shot.
Writes music/score.ogg and sfx/{fire,night,water}.ogg, sfx/{ignite,chime}.wav.
"""
import os
import subprocess
import sys

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

RATE = 44100
RNG = np.random.default_rng(11)


def t_axis(seconds):
    return np.arange(int(seconds * RATE)) / RATE


def lowpass(x, f, order=2):
    return sosfilt(butter(order, f, "low", fs=RATE, output="sos"), x)


def highpass(x, f, order=2):
    return sosfilt(butter(order, f, "high", fs=RATE, output="sos"), x)


def bandpass(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], "band", fs=RATE, output="sos"), x)


def hz(name):
    names = {"C": -9, "C#": -8, "Db": -8, "D": -7, "D#": -6, "Eb": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "A": 0, "A#": 1, "Bb": 1, "B": 2}
    return 440.0 * 2 ** ((names[name[:-1]] + (int(name[-1]) - 4) * 12) / 12)


def place(track, sound, at, gain=1.0):
    i = int(at * RATE)
    if i >= len(track) or i < 0:
        return
    end = min(len(track), i + len(sound))
    track[i:end] += sound[: end - i] * gain


def reverb(x, amount=0.3, size=1.0):
    out = x.copy()
    for delay, gain in [(0.031, 0.62), (0.043, 0.58), (0.057, 0.55), (0.071, 0.5), (0.089, 0.46)]:
        d = int(delay * size * RATE)
        y = np.zeros_like(x)
        y[d:] = x[:-d]
        for _ in range(6):
            y[d:] += y[:-d] * gain * 0.55
        out += lowpass(y, 5000) * amount * gain
    return out


def normalise(x, peak=0.85):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak


def write_wav(path, x):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    wavfile.write(path, RATE, (normalise(x) * 32767).astype(np.int16))


def write_ogg(path, x, peak=0.85):
    tmp = path[:-4] + ".tmp.wav"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    wavfile.write(tmp, RATE, (normalise(x, peak) * 32767).astype(np.int16))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libvorbis", "-q:a", "5", path], check=True)
    os.remove(tmp)


# --- Instruments ---------------------------------------------------------------------

def piano(freq, seconds=3.0, velocity=0.7):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for k in range(1, 9):
        partial = freq * k * (1 + 0.0004 * k * k)  # slight stiffness
        decay = 1.2 + k * 0.9
        out += np.sin(2 * np.pi * partial * t) * np.exp(-t * decay) / (k ** 1.15)
    hammer = bandpass(RNG.standard_normal(len(t)), 1500, 5000) * np.exp(-t * 120) * 0.05
    attack = np.clip(t / 0.004, 0, 1)
    return (out * attack + hammer) * velocity * (1.0 - np.clip((t - seconds + 0.3) / 0.3, 0, 1))


def strings(freq, seconds, attack=1.2, bright=1800):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for detune in (-0.004, 0.0, 0.005):
        vib = 1 + 0.003 * np.sin(2 * np.pi * 5.0 * t + detune * 900)
        phase = np.cumsum(freq * (1 + detune) * vib) / RATE
        for k in range(1, 10):
            out += np.sin(2 * np.pi * k * phase) / k
    env = np.clip(t / attack, 0, 1) * np.clip((seconds - t) / min(1.5, seconds * 0.4), 0, 1)
    return lowpass(out * env, bright) * 0.18


def choir(freq, seconds):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for detune in (-0.003, 0.004):
        phase = np.cumsum(freq * (1 + detune) * (1 + 0.004 * np.sin(2 * np.pi * 4.6 * t))) / RATE
        for k in range(1, 14):
            out += np.sin(2 * np.pi * k * phase) / k
    voiced = bandpass(out, 500, 900) + bandpass(out, 1000, 1400) * 0.5
    env = np.clip(t / 2.0, 0, 1) * np.clip((seconds - t) / 2.0, 0, 1)
    return voiced * env * 0.25


def bell(freq, seconds=4.0):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for ratio, amp, decay in [(1, 1, 1.2), (2.76, 0.5, 2.0), (5.4, 0.25, 3.5), (8.93, 0.12, 5.0)]:
        out += np.sin(2 * np.pi * freq * ratio * t) * amp * np.exp(-t * decay)
    return out * np.clip(t / 0.002, 0, 1) * 0.4


def cello_pluck(freq, seconds=1.4):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for k in range(1, 7):
        out += np.sin(2 * np.pi * freq * k * t) * np.exp(-t * (3 + k)) / k
    return lowpass(out, 1200) * 0.6


CHORDS = {
    "Am": ["A2", "E3", "A3", "C4", "E4"], "F": ["F2", "C3", "F3", "A3", "C4"], "C": ["C3", "G3", "C4", "E4", "G4"],
    "G": ["G2", "D3", "G3", "B3", "D4"], "Em": ["E2", "B2", "E3", "G3", "B3"], "Dm": ["D3", "A3", "D4", "F4", "A4"],
    "Fmaj7": ["F2", "C3", "E3", "A3", "C4"], "Cadd9": ["C3", "G3", "D4", "E4", "G4"], "Gsus": ["G2", "D3", "G3", "C4", "D4"],
}
THEME = [("E5", 1), ("D5", 0.5), ("C5", 0.5), ("D5", 1), ("E5", 1), (None, 0.5), ("G5", 0.5), ("E5", 1), ("D5", 2),
         ("C5", 1), ("D5", 0.5), ("E5", 0.5), ("A4", 2), (None, 1), ("C5", 0.5), ("D5", 0.5), ("E5", 1.5), ("D5", 0.5), ("C5", 2), (None, 2)]


def section(track, start, end, chords, beat, parts, theme_gain=0.0, fade_in=2.0, fade_out=2.0):
    """Plays the chord loop from start to end with the chosen parts."""
    t = start
    i = 0
    layer = np.zeros(len(track))
    while t < end - 0.5:
        chord = CHORDS[chords[i % len(chords)]]
        bar = 4 * beat
        length = min(bar, end - t)
        if "pad" in parts:
            for n in chord[1:4]:
                place(layer, strings(hz(n), length + 1.0, attack=1.5, bright=1400), t, 0.55)
        if "strings" in parts:
            for n in chord:
                place(layer, strings(hz(n), length + 1.2, attack=0.9, bright=2600), t, 0.8)
        if "choir" in parts:
            for n in chord[2:]:
                place(layer, choir(hz(n), length + 1.5), t, 0.9)
        if "bass" in parts:
            place(layer, strings(hz(chord[0]), length + 0.8, attack=0.6, bright=600), t, 1.1)
        if "pulse" in parts:
            for b in range(4):
                place(layer, cello_pluck(hz(chord[0])), t + b * beat, 0.5 if b % 2 == 0 else 0.3)
        if "arp" in parts:
            notes = chord[1:] + chord[2:4][::-1]
            for k in range(8):
                at = t + k * beat * 0.5
                if at < end:
                    place(layer, piano(hz(notes[k % len(notes)]) * 2 ** (1 if k % 4 == 3 else 0), 2.5, 0.28), at)
        if "bells" in parts:
            for k, n in enumerate(chord[2:]):
                place(layer, bell(hz(n) * 2), t + k * beat * 1.3 + 0.2, 0.35)
        t += bar
        i += 1
    if theme_gain > 0:
        t = start + 4 * beat
        while t < end - 4:
            for n, length in THEME:
                if t >= end - 2:
                    break
                if n:
                    place(layer, piano(hz(n), max(length * beat * 1.5, 1.2), 0.55), t, theme_gain)
                t += length * beat
            t += 4 * beat
    a, b = int(start * RATE), int(min(end + 2.0, len(track) / RATE) * RATE)
    ramp = np.ones(b - a)
    fi = int(fade_in * RATE)
    fo = int(fade_out * RATE)
    ramp[:fi] = np.linspace(0, 1, fi)
    tail = int((min(end + 2.0, len(track) / RATE) - end) * RATE) + fo
    ramp[-tail:] *= np.linspace(1, 0, tail)
    track[a:b] += layer[a:b] * ramp


def score(length, s2, s3, s4, release, ending):
    track = np.zeros(int((length + 4) * RATE))
    beat = 1.0  # 60 bpm
    section(track, 0.0, s2, ["Am", "F", "C", "G"], beat, ["pad", "arp"], fade_in=4.0)
    section(track, s2, s3, ["Am", "Em", "F", "C", "Dm", "Am", "F", "G"], beat, ["pad", "arp", "bass"], theme_gain=0.9)
    section(track, s3, release, ["F", "G", "Em", "Am"], beat, ["pad", "pulse", "bass"], theme_gain=0.6)
    section(track, release, ending, ["F", "G", "Am", "C", "Fmaj7", "G", "C", "Cadd9"], beat,
            ["strings", "choir", "bass", "bells", "arp"], theme_gain=1.0, fade_in=6.0)
    # Coda: piano alone, theme fragment, last chord ringing.
    t = ending + 0.5
    for n, length_ in THEME[:9]:
        if n:
            place(track, piano(hz(n), 3.0, 0.5), t)
        t += length_ * 1.2
    for n in ["C3", "G3", "E4", "G4", "C5"]:
        place(track, piano(hz(n), 8.0, 0.35), min(t + 0.5, length - 6.0))
    track = reverb(track, 0.45, 1.3)
    end = int(length * RATE)
    track = track[:end]
    fade = int(4.0 * RATE)
    track[-fade:] *= np.linspace(1, 0, fade)
    return track


# --- Ambience and effects ---------------------------------------------------------------

def fire(seconds):
    n = int(seconds * RATE)
    rumble = lowpass(RNG.standard_normal(n), 180) * 0.8
    roar = bandpass(RNG.standard_normal(n), 300, 1500) * (0.12 + 0.06 * np.sin(np.arange(n) / RATE * 0.7))
    out = rumble + roar
    t = 0.0
    while t < seconds:
        pop = t_axis(0.03)
        burst = bandpass(RNG.standard_normal(len(pop)), 1500, 6000) * np.exp(-pop * 160) * RNG.uniform(0.6, 2.5)
        place(out, burst, t)
        t += RNG.exponential(0.18)
    return out


def night(seconds):
    n = int(seconds * RATE)
    wind = lowpass(RNG.standard_normal(n), 400) * (0.25 + 0.15 * np.sin(np.arange(n) / RATE * 0.21))
    out = wind
    for freq, rate, phase in [(4300, 18, 0.0), (4700, 21, 1.3), (3900, 16, 2.1)]:
        t = t_axis(seconds)
        chirps = (np.sin(2 * np.pi * rate * t) > 0.2).astype(float) * (np.sin(2 * np.pi * 0.45 * t + phase) > -0.1)
        out += np.sin(2 * np.pi * freq * t) * lowpass(chirps, 60) * 0.06
    return out


def water(seconds):
    n = int(seconds * RATE)
    t = np.arange(n) / RATE
    swell = 0.5 + 0.5 * np.sin(2 * np.pi * t / 4.2) ** 2 + 0.2 * np.sin(2 * np.pi * t / 2.3)
    return lowpass(RNG.standard_normal(n), 900) * swell * 0.6 + bandpass(RNG.standard_normal(n), 1200, 3500) * swell ** 3 * 0.05


def ignite():
    t = t_axis(2.2)
    sweep = np.zeros_like(t)
    noise = RNG.standard_normal(len(t))
    for i in range(0, len(t), 1024):
        f = 300 + 2200 * min(1.0, i / RATE / 0.5)
        sweep[i:i + 1024] = bandpass(noise[i:i + 1024], f * 0.6, min(f * 1.6, 18000))
    env = np.clip(t / 0.4, 0, 1) * np.exp(-np.clip(t - 0.4, 0, None) * 2.0)
    thump = np.sin(2 * np.pi * 70 * t) * np.exp(-t * 6) * 0.4
    return reverb(sweep * env * 0.6 + thump + lowpass(noise, 300) * env * 0.4, 0.3)


def chime():
    out = np.zeros(int(6 * RATE))
    for k, n in enumerate(["E6", "G6", "C7", "D6", "G6"]):
        place(out, bell(hz(n), 5.0), k * 0.45 + RNG.uniform(0, 0.1), 0.8)
    return reverb(out, 0.5)


def main():
    folder = sys.argv[1]
    length, s2, s3, s4, release, ending = (float(v) for v in sys.argv[2:8])
    write_ogg(os.path.join(folder, "music", "score.ogg"), score(length, s2, s3, s4, release, ending))
    write_ogg(os.path.join(folder, "sfx", "fire.ogg"), fire(length), 0.6)
    write_ogg(os.path.join(folder, "sfx", "night.ogg"), night(length), 0.6)
    write_ogg(os.path.join(folder, "sfx", "water.ogg"), water(length - s3 + 2), 0.6)
    write_wav(os.path.join(folder, "sfx", "ignite.wav"), ignite())
    write_wav(os.path.join(folder, "sfx", "chime.wav"), chime())
    print("AUDIO OK", length, s2, s3, s4, release, ending)


main()
