"""Sky lanterns for "The Lantern, Part Two", made in Blender and exported as .glb:
  sky_lantern.glb      unlit paper lantern (cream paper, bamboo ring, fuel cell)
  sky_lantern_lit.glb  the same, glowing warm amber, with a soft light inside
Run:  python make_lantern_props.py -- <models folder>
"""
import math
import os
import sys

import bpy
import bmesh

OUT = sys.argv[sys.argv.index("--") + 1]
HEIGHT = 0.95
R_TOP = 0.33
R_BOTTOM = 0.24


def material(name, color, rough=0.8, emission=0.0, emission_color=None, alpha=1.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*color, 1)
    b.inputs["Roughness"].default_value = rough
    if emission > 0:
        b.inputs["Emission Color"].default_value = (*(emission_color or color), 1)
        b.inputs["Emission Strength"].default_value = emission
    if alpha < 1.0:
        b.inputs["Alpha"].default_value = alpha
    return m


def paper_body(mat):
    """Open-bottomed paper bag: tapered, domed top, soft vertical creases."""
    mesh = bpy.data.meshes.new("Paper")
    obj = bpy.data.objects.new("Paper", mesh)
    bpy.context.collection.objects.link(obj)
    bm = bmesh.new()
    rings, segs = 18, 48
    verts = []
    for r in range(rings + 1):
        f = r / rings  # 0 bottom .. 1 top
        radius = R_BOTTOM + (R_TOP - R_BOTTOM) * max(0.0, math.sin(f * math.pi * 0.5)) ** 0.8
        z = HEIGHT * 0.1 + f * HEIGHT * 0.78
        if f > 0.82:  # dome
            k = (f - 0.82) / 0.18
            radius *= max(0.0, math.cos(k * math.pi * 0.5)) ** 0.6
            z += k * HEIGHT * 0.08
        row = []
        for s in range(segs):
            a = s / segs * math.tau
            crease = 1.0 + 0.025 * math.cos(a * 8)  # 8 paper panels
            row.append(bm.verts.new((math.cos(a) * radius * crease, math.sin(a) * radius * crease, z)))
        verts.append(row)
    for r in range(rings):
        for s in range(segs):
            bm.faces.new([verts[r][s], verts[r][(s + 1) % segs], verts[r + 1][(s + 1) % segs], verts[r + 1][s]])
    top = bm.verts.new((0, 0, HEIGHT * 0.96))
    for s in range(segs):
        bm.faces.new([verts[rings][s], verts[rings][(s + 1) % segs], top])
    bm.to_mesh(mesh)
    bm.free()
    for poly in mesh.polygons:
        poly.use_smooth = True
    mod = obj.modifiers.new("Thick", "SOLIDIFY")
    mod.thickness = 0.004
    obj.data.materials.append(mat)
    return obj


def build(lit):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if lit:
        paper = material("PaperLit", (1.0, 0.62, 0.3), rough=0.9, emission=3.2, emission_color=(1.0, 0.45, 0.12))
        flame = material("Flame", (1.0, 0.8, 0.4), emission=25.0, emission_color=(1.0, 0.65, 0.25))
    else:
        paper = material("Paper", (0.93, 0.86, 0.72), rough=0.9)
        flame = material("Fuel", (0.25, 0.2, 0.15))
    bamboo = material("Bamboo", (0.45, 0.32, 0.17), rough=0.7)
    wire = material("Wire", (0.15, 0.14, 0.13), rough=0.4)
    paper_body(paper)
    # Bamboo ring at the opening and cross wires holding the fuel cell.
    bpy.ops.mesh.primitive_torus_add(major_radius=R_BOTTOM, minor_radius=0.008, major_segments=48, minor_segments=8,
                                     location=(0, 0, HEIGHT * 0.1))
    bpy.context.object.data.materials.append(bamboo)
    for angle in (0.0, math.pi / 2):
        bpy.ops.mesh.primitive_cylinder_add(radius=0.002, depth=R_BOTTOM * 2, location=(0, 0, HEIGHT * 0.1),
                                            rotation=(0, math.pi / 2, angle))
        bpy.context.object.data.materials.append(wire)
    bpy.ops.mesh.primitive_cylinder_add(radius=0.035, depth=0.03, location=(0, 0, HEIGHT * 0.1))
    bpy.context.object.data.materials.append(flame)
    if lit:
        bpy.ops.mesh.primitive_uv_sphere_add(radius=0.03, location=(0, 0, HEIGHT * 0.16))
        bpy.context.object.scale = (1, 1, 1.8)
        bpy.context.object.data.materials.append(flame)
    # Join the meshes, apply modifiers.
    meshes = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    for o in meshes:
        o.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    bpy.ops.object.convert(target="MESH")
    bpy.ops.object.join()
    lantern = bpy.context.object
    lantern.name = "SkyLantern"
    if lit:
        # A warm light inside (Scene Builder 1.5+ tames imported light levels
        # and switches lights off while their object is hidden).
        light = bpy.data.lights.new("LanternGlow", "POINT")
        light.energy = 40.0
        light.color = (1.0, 0.62, 0.3)
        light.shadow_soft_size = 0.15
        glow = bpy.data.objects.new("LanternGlow", light)
        bpy.context.collection.objects.link(glow)
        glow.location = (0, 0, HEIGHT * 0.35)
        glow.parent = lantern
    name = "sky_lantern_lit.glb" if lit else "sky_lantern.glb"
    path = os.path.join(OUT, name)
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB", export_lights=True, export_apply=True)
    print("EXPORTED", path)


os.makedirs(OUT, exist_ok=True)
build(False)
build(True)
