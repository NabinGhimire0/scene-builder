THE LANTERN, PART TWO - a 3½-minute Scene Builder film
=======================================================

Part One ended at dusk, by a lakeside fire: "Every lantern finds its way home."

Part Two: night falls. Ram, the old man who kept the fire burning, tells Mira
why he comes back to this lake every autumn. Sixty years ago he and her
grandfather, two lost boys, found it in the rain, and every year since they
lit one lantern for everything they could not say out loud. This year her
grandfather cannot climb the hill. So Mira lights it for him, and as it rises
over the water, she sees that she is not alone.

HOW TO WATCH
1. Use the Scene Builder from the same delivery (it adds "rises" for objects).
2. Script -> Open... -> choose the_lantern_part_two.zip -> Build Film -> Watch.
3. Export Video -> MP4 (needs FFmpeg for the score and ambience). Cinematic
   quality looks best; the lanterns glow against the night sky.
   Tip: play "My First Film: The Lantern" (New menu) first, then this one.

WHAT'S INSIDE
film.script                4 scenes, 2 characters, 37 camera shots, 3:41
models/sky_lantern.glb     paper sky lantern, unlit       (made in Blender)
models/sky_lantern_lit.glb the same lantern, glowing      (made in Blender)
music/score.ogg            original score: piano by the fire, the lantern theme,
                           a cello pulse to the water, strings, choir and bells
                           as the lanterns rise, solo piano to close
sfx/fire.ogg, night.ogg    crackling campfire; crickets and night wind
sfx/water.ogg              water lapping at the shore
sfx/ignite.wav, chime.wav  the lantern catching light; distant chimes
tools/                     the Blender and audio scripts that made these files

Everything here is original and made for this film; use it freely.

MAKE IT YOURS
- Use your own avatars: CAST -> Mira = <your avatar's name>.
- Add real voices: record each line (Film tab -> Record Voice), save them in an
  audio/ folder and add [audio: audio/ram_01.wav] to the dialogue lines.
- More lanterns: copy a "farN = models/sky_lantern_lit.glb at (x, z)" line,
  hide it at the start ("farN disappears"), then "farN appears" and
  "farN rises 30m over 20s &" where you want it.
