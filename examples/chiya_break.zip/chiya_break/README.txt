CHIYA BREAK - a one-minute sample film package for Scene Builder 1.5.1
=====================================================================

Four o'clock, chiya time. There are twelve biscuits in the jar, and Sanu
thinks nobody counts biscuits. Babu does. Then Aama walks in.

This is the small sample package that goes with FILM_PACKAGE_PROMPT.md: it
shows every part of a package in its simplest form.

HOW TO WATCH
Script -> Open... -> chiya_break.zip -> Build Film -> Watch.

WHAT'S INSIDE
film.script             the screenplay (3 scenes, 3 characters, 12 shots, ~58 s)
models/biscuit_jar.glb  glass biscuit jar with a red lid   (made by tools/make_props.py)
models/chiya_cup.glb    a glass of chiya on a steel saucer (made by tools/make_props.py)
music/theme.ogg         sneaky tea-time tune, 56 s          (made by tools/make_audio.py)
sfx/crunch.wav, sfx/slurp.wav, sfx/dun.wav                  (made by tools/make_audio.py)
tools/make_props.py     Blender (bpy) script that builds the models
tools/make_audio.py     numpy/scipy script that composes the music and effects

Re-make the files:  blender --background --python tools/make_props.py -- models
                    python tools/make_audio.py . 56
All files are original and free to use.
