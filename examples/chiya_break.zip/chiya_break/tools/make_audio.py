"""Original music and sound effects for "Chiya Break", synthesised with numpy/scipy
(no samples, no recordings). Needs: numpy, scipy, ffmpeg (for .ogg).
Run:  python make_audio.py <film folder> [music seconds]
"""
import os
import subprocess
import sys

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

RATE = 44100
RNG = np.random.default_rng(3)


def t_axis(seconds):
    return np.arange(int(seconds * RATE)) / RATE


def band(x, lo, hi):
    return sosfilt(butter(2, [lo, hi], "band", fs=RATE, output="sos"), x)


def low(x, f):
    return sosfilt(butter(2, f, "low", fs=RATE, output="sos"), x)


def env(n, attack=0.005, release=0.1):
    e = np.ones(n)
    a, r = max(1, int(attack * RATE)), max(1, int(release * RATE))
    e[:a] = np.linspace(0, 1, a)
    e[-r:] *= np.linspace(1, 0, r)
    return e


def place(track, sound, at):
    i = int(at * RATE)
    end = min(len(track), i + len(sound))
    if 0 <= i < len(track):
        track[i:end] += sound[: end - i]


def note(name):
    names = {"C": -9, "D": -7, "E": -5, "F": -4, "G": -2, "A": 0, "B": 2}
    return 440.0 * 2 ** ((names[name[0]] + (int(name[-1]) - 4) * 12) / 12)


def write_wav(path, x):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    x = x / (np.max(np.abs(x)) or 1) * 0.85
    wavfile.write(path, RATE, (x * 32767).astype(np.int16))


def write_ogg(path, x):
    tmp = path[:-4] + ".tmp.wav"
    write_wav(tmp, x)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libvorbis", "-q:a", "5", path], check=True)
    os.remove(tmp)


def pluck(freq, seconds=0.4):
    t = t_axis(seconds)
    x = sum(np.sin(2 * np.pi * freq * k * t) / k for k in range(1, 8))
    return low(x * np.exp(-t * 8), 3000) * env(len(t), 0.002, 0.05)


def bass(freq, seconds):
    t = t_axis(seconds)
    return np.sin(2 * np.pi * freq * t) * np.exp(-t * 3) * env(len(t), 0.004, 0.05)


def tick(high):
    t = t_axis(0.1)
    return np.sin(2 * np.pi * (1100 if high else 800) * t) * np.exp(-t * 45)


def theme(seconds):
    """Light, sneaky tea-time tune: pizzicato over a walking bass, 100 bpm, fades at the end."""
    beat = 60 / 100
    track = np.zeros(int((seconds + 1) * RATE))
    walk = ["C3", "E3", "G3", "A3", "F3", "A3", "G3", "B3"]
    tune = ["E5", "G5", "A5", "G5", "E5", "D5", "C5", "D5"]
    t, i = 0.0, 0
    while t < seconds:
        place(track, bass(note(walk[i % 8]), beat) * 0.6, t)
        place(track, tick(i % 2 == 0) * 0.3, t)
        if (i // 8) % 2 == 1:
            place(track, pluck(note(tune[i % 8])) * 0.4, t + beat * 0.5)
        t += beat
        i += 1
    track = track[: int(seconds * RATE)]
    fade = int(2.0 * RATE)
    track[-fade:] *= np.linspace(1, 0, fade)
    return track


def slurp():
    t = t_axis(0.9)
    noise = RNG.standard_normal(len(t))
    out = np.zeros_like(t)
    for i in range(0, len(t), 1024):
        c = 600 + 1800 * (i / len(t))
        out[i:i + 1024] = band(noise[i:i + 1024], c * 0.8, c * 1.3)
    return out * (0.4 + 0.6 * np.abs(np.sin(2 * np.pi * 7 * t))) * env(len(t), 0.05, 0.2)


def crunch():
    out = np.zeros(int(0.8 * RATE))
    for k in range(7):
        t = t_axis(0.06)
        place(out, band(RNG.standard_normal(len(t)), 900, 7000) * np.exp(-t * 60), k * 0.1 + RNG.uniform(0, 0.03))
    return out


def dun():
    out = np.zeros(int(2.6 * RATE))
    for at, length in [(0.0, 0.3), (0.4, 0.3), (0.85, 1.6)]:
        t = t_axis(length)
        hit = sum(sum(np.sin(2 * np.pi * note(n) * k * t) / k for k in range(1, 9)) for n in ["D3", "F3", "A3"])
        place(out, low(hit, 2000) * env(len(t), 0.02, 0.2) * 0.3, at)
    return out


def main():
    folder = sys.argv[1]
    seconds = float(sys.argv[2]) if len(sys.argv) > 2 else 40.0
    write_ogg(os.path.join(folder, "music", "theme.ogg"), theme(seconds))
    for name, fn in [("slurp", slurp), ("crunch", crunch), ("dun", dun)]:
        write_wav(os.path.join(folder, "sfx", name + ".wav"), fn())
    print("AUDIO OK")


main()
