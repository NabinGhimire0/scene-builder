"""Props for "Chiya Break", built with Blender's Python (bpy) and exported as .glb.
Run:  blender --background --python make_props.py -- <models folder>
(or with the bpy pip module:  python make_props.py -- <models folder>)

Rules every prop follows: real size in metres, origin at the bottom centre
(it rests on whatever it is placed "on"), Principled materials, one joined mesh.
"""
import math
import os
import sys

import bpy

OUT = sys.argv[sys.argv.index("--") + 1]


def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def material(name, color, rough=0.5, metal=0.0, alpha=1.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*color, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    if alpha < 1.0:
        b.inputs["Alpha"].default_value = alpha
        m.blend_method = "BLEND"
    return m


def add(obj_op, mat, smooth=True, **kwargs):
    obj_op(**kwargs)
    obj = bpy.context.object
    obj.data.materials.append(mat)
    if smooth:
        bpy.ops.object.shade_smooth()
    return obj


def solidify(obj, thickness):
    mod = obj.modifiers.new("Solid", "SOLIDIFY")
    mod.thickness = thickness
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_apply(modifier="Solid")


def join_and_export(name, filename):
    bpy.ops.object.select_all(action="SELECT")
    bpy.context.view_layer.objects.active = [o for o in bpy.context.scene.objects if o.type == "MESH"][0]
    bpy.ops.object.join()
    bpy.context.object.name = name
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    path = os.path.join(OUT, filename)
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB", export_apply=True)
    print("EXPORTED", path)


def chiya_cup():
    """A glass of milky Nepali tea on a small steel saucer (a little larger than life so it reads on camera)."""
    steel = material("Steel", (0.8, 0.8, 0.82), rough=0.2, metal=1.0)
    glass = material("Glass", (0.9, 0.95, 1.0), rough=0.05, alpha=0.35)
    tea = material("Tea", (0.62, 0.4, 0.22), rough=0.15)
    add(bpy.ops.mesh.primitive_cylinder_add, steel, vertices=48, radius=0.075, depth=0.008, location=(0, 0, 0.004))
    cup = add(bpy.ops.mesh.primitive_cone_add, glass, vertices=48, radius1=0.04, radius2=0.05, depth=0.11,
              location=(0, 0, 0.063), end_fill_type="NOTHING")
    solidify(cup, 0.003)
    add(bpy.ops.mesh.primitive_cylinder_add, tea, vertices=48, radius=0.046, depth=0.085, location=(0, 0, 0.052))


def biscuit_jar():
    """A glass jar with a red lid, half full of round biscuits."""
    glass = material("JarGlass", (0.85, 0.92, 0.95), rough=0.05, alpha=0.3)
    lid = material("Lid", (0.75, 0.12, 0.1), rough=0.4)
    biscuit = material("Biscuit", (0.82, 0.6, 0.3), rough=0.7)
    jar = add(bpy.ops.mesh.primitive_cylinder_add, glass, vertices=48, radius=0.09, depth=0.2, location=(0, 0, 0.1),
              end_fill_type="NGON")
    solidify(jar, 0.004)
    add(bpy.ops.mesh.primitive_cylinder_add, lid, vertices=48, radius=0.095, depth=0.03, location=(0, 0, 0.215))
    add(bpy.ops.mesh.primitive_uv_sphere_add, lid, radius=0.02, location=(0, 0, 0.235))
    for i in range(14):
        a = i * 2.4
        r = 0.045 if i % 2 else 0.02
        b = add(bpy.ops.mesh.primitive_cylinder_add, biscuit, vertices=24, radius=0.032, depth=0.012,
                location=(r * math.cos(a), r * math.sin(a), 0.012 + i * 0.008))
        b.rotation_euler = (0.5 * math.sin(i), 0.5 * math.cos(i * 1.3), 0)


def main():
    os.makedirs(OUT, exist_ok=True)
    for name, build in [("chiya_cup", chiya_cup), ("biscuit_jar", biscuit_jar)]:
        reset()
        build()
        join_and_export(name.replace("_", " ").title(), name + ".glb")


main()
