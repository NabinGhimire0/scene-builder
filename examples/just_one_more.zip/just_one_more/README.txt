JUST ONE MORE  (about 1 min 27 s)
An original Scene Builder short in the Flat sketch style.

Logline: the night before a mock test, Mina's phone buzzes. "Later", the shadow who
lives in her scrolling, whispers "just one more video" - and the night is gone. The
next morning she deletes the app. Day after day he keeps whispering; day after day
she keeps going. He never fully leaves. He just gets quieter.

HOW TO WATCH
  Needs Scene Builder 1.9 or newer (the Flat sketch style is new in 1.9).
  Script -> Open... -> just_one_more.zip -> Build Film -> Watch.
  There is no spoken dialogue: the shadow's whispers float next to his head as
  handwritten words, and the music tells the rest.

CHAPTERS
    0:00  The night before    11:02 PM, a buzz, "Just one more video.", the feed, 2:17 AM
    0:30  The morning after   DAYS FOCUSED: 0, a bad result, "Delete Clips?" - Delete
    0:45  Day after day       Day 1, Day 6, Day 13: he whispers, she almost gives in
    1:02  Quieter             Day 30, a good result, she walks on; "He never fully leaves."

CAST
  Mina  = sketch person (cream). Her face does the acting: tired, ashamed, determined...
  Later = the shadow (black with a violet glow).
  Try your own colours in the CAST lines: "color pale yellow", "glow red".

LOCATION
  Sketch Stage (the black void with one floor line), STYLE: flat.

FILES
  film.script            the film
  music/*.ogg            5 original cues: night_desk, scroll, morning, day_after_day, quieter
  sfx/*.wav              buzz, tap, pop, whoosh, crack, clock
  tools/make_audio.py    composes the music and sound effects (python, numpy, scipy, ffmpeg)
  storyboard.png         frames from a test build

Every note and sound in this package was made from scratch by the tool. The style was
inspired by flat 2D motivational shorts about the voice in your head; the characters,
story, lines and music are original. "Clips" is a made-up app.
