"""Original music and sound effects for JUST ONE MORE, synthesised from scratch
(no samples, no recordings). Usage:
    python tools/make_audio.py
Needs numpy, scipy and ffmpeg (for .ogg). Music -> music/*.ogg, effects -> sfx/*.wav.

The score follows the story: a quiet, lonely piano at the desk at night, a
hypnotic plucked loop while she scrolls (the time disappears), a cold thin
morning, a steady ostinato for the days of work, and a warm major ending.
Cue lengths (seconds) are at the bottom: each fits its scene and ends with a fade.
"""
import os
import subprocess

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

RATE = 44100
RNG = np.random.default_rng(2026)
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")


# --- Building blocks ---------------------------------------------------------------

def t_axis(seconds):
    return np.arange(int(seconds * RATE)) / RATE


def lowpass(x, f, order=2):
    return sosfilt(butter(order, f, "low", fs=RATE, output="sos"), x)


def highpass(x, f, order=2):
    return sosfilt(butter(order, f, "high", fs=RATE, output="sos"), x)


def hz(name):
    names = {"C": -9, "C#": -8, "D": -7, "D#": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "A": 0, "A#": 1, "B": 2}
    return 440.0 * 2 ** ((names[name[:-1]] + (int(name[-1]) - 4) * 12) / 12)


def place(track, sound, at):
    i = int(at * RATE)
    if i >= len(track):
        return
    end = min(len(track), i + len(sound))
    track[i:end] += sound[: end - i]


def reverb(x, amount=0.3):
    out = x.copy()
    for delay, gain in [(0.031, 0.6), (0.043, 0.5), (0.059, 0.45), (0.083, 0.4), (0.113, 0.35), (0.157, 0.3)]:
        d = int(delay * RATE)
        y = np.zeros_like(x)
        y[d:] = x[:-d]
        for _ in range(5):
            y[d:] += y[:-d] * gain * 0.55
        out += y * amount * gain
    return out


def fade(x, fade_in=0.05, fade_out=2.0):
    n = len(x)
    e = np.ones(n)
    a = int(fade_in * RATE)
    b = int(fade_out * RATE)
    if a:
        e[:a] = np.linspace(0, 1, a)
    if b:
        e[-b:] *= np.linspace(1, 0, b) ** 1.5
    return x * e


def normalise(x, peak=0.85):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak


def piano(freq, seconds=2.5, velocity=1.0):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for k, amp in enumerate([1.0, 0.45, 0.25, 0.12, 0.08, 0.04], start=1):
        f = freq * k * (1 + 0.0004 * k * k)
        out += amp * np.sin(2 * np.pi * f * t) * np.exp(-t * (1.2 + 0.9 * k))
    hammer = np.exp(-t * 60) * RNG.standard_normal(len(t)) * 0.02
    attack = np.minimum(1, t / 0.004)
    return (out + hammer) * attack * velocity


def pad(freqs, seconds, brightness=900, detune=0.003):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for f in freqs:
        for d in (-detune, 0, detune):
            phase = 2 * np.pi * f * (1 + d) * t
            out += sum(np.sin(k * phase) / k for k in range(1, 8))
    out = lowpass(out, brightness, 2)
    swell = np.minimum(1, t / 1.5) * np.minimum(1, (seconds - t) / 1.5)
    return out * swell / (len(freqs) * 3)


def strings(freq, seconds, attack=0.08):
    t = t_axis(seconds)
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t)
    phase = 2 * np.pi * freq * np.cumsum(vib) / RATE
    out = sum(np.sin(k * phase) * (0.7 ** k) for k in range(1, 9))
    env = np.minimum(1, t / attack) * np.minimum(1, (seconds - t) / 0.05)
    return lowpass(out, 2600) * env


def kick(seconds=0.6, depth=1.0):
    t = t_axis(seconds)
    f = 45 + 110 * np.exp(-t * 28)
    body = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 7)
    click = RNG.standard_normal(len(t)) * np.exp(-t * 180) * 0.15
    return (body + click) * depth


def taiko(seconds=1.2):
    t = t_axis(seconds)
    f = 62 + 50 * np.exp(-t * 12)
    body = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 3.2)
    skin = lowpass(RNG.standard_normal(len(t)), 700) * np.exp(-t * 14) * 0.5
    return body + skin


def snare(seconds=0.35):
    t = t_axis(seconds)
    noise = highpass(RNG.standard_normal(len(t)), 1800) * np.exp(-t * 20)
    tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t * 30) * 0.5
    return (noise * 0.6 + tone) * 0.8


def hat(seconds=0.08):
    t = t_axis(seconds)
    return highpass(RNG.standard_normal(len(t)), 7000) * np.exp(-t * 60) * 0.25


def heartbeat():
    beat = np.zeros(int(0.9 * RATE))
    place(beat, kick(0.4, 1.0) * 0.9, 0.0)
    place(beat, kick(0.4, 0.7) * 0.6, 0.22)
    return lowpass(beat, 160)


def to_ogg(name, x):
    os.makedirs(os.path.join(ROOT, "music"), exist_ok=True)
    wav = os.path.join(ROOT, "music", name + ".wav")
    stereo = np.stack([x, np.roll(x, 180)], axis=1)
    wavfile.write(wav, RATE, (normalise(stereo, 0.9) * 32767).astype(np.int16))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "5",
                    os.path.join(ROOT, "music", name + ".ogg")], check=True)
    os.remove(wav)


def to_wav(name, x, peak=0.9):
    os.makedirs(os.path.join(ROOT, "sfx"), exist_ok=True)
    stereo = np.stack([x, np.roll(x, 90)], axis=1)
    wavfile.write(os.path.join(ROOT, "sfx", name + ".wav"), RATE, (normalise(stereo, peak) * 32767).astype(np.int16))


# --- Cues ---------------------------------------------------------------------------


def pluck(freq, seconds=0.5, bright=3000):
    t = t_axis(seconds)
    out = sum(np.sin(2 * np.pi * freq * k * t) * (0.6 ** k) for k in range(1, 6))
    return lowpass(out * np.exp(-t * 9) * np.minimum(1, t / 0.003), bright)


def sub_drone(freq, seconds):
    t = t_axis(seconds)
    out = np.sin(2 * np.pi * freq * t) + 0.3 * np.sin(2 * np.pi * freq * 2.003 * t)
    return out * np.minimum(1, t / 3.0) * np.minimum(1, (seconds - t) / 2.0)


# --- Cues ---------------------------------------------------------------------------

def night_desk(seconds):
    """Lonely piano in A minor over a soft pad."""
    out = np.zeros(int(seconds * RATE) + RATE * 3)
    chords = [["A2", "E3", "C4"], ["F2", "C3", "A3"], ["C3", "G3", "E4"], ["G2", "D3", "B3"]]
    melody = ["E5", "C5", "D5", "B4", "C5", "A4", "G4", "B4"]
    bar = 3.2
    k = 0
    at = 0.0
    while at < seconds:
        chord = chords[k % 4]
        place(out, pad([hz(n) for n in chord], bar + 0.6, 700) * 0.5, at)
        for i, n in enumerate(chord):
            place(out, piano(hz(n), 3.0, 0.35), at + i * 0.12)
        place(out, piano(hz(melody[(2 * k) % 8]), 2.5, 0.5), at + 0.8)
        place(out, piano(hz(melody[(2 * k + 1) % 8]), 2.5, 0.4), at + 2.2)
        at += bar
        k += 1
    return fade(reverb(out[: int(seconds * RATE)], 0.45), 0.5, 2.0)


def scroll(seconds):
    """A hypnotic plucked loop that never resolves; a low drone grows under it."""
    out = np.zeros(int(seconds * RATE) + RATE)
    notes = ["A4", "C5", "E5", "A5", "G5", "E5", "C5", "E5"]
    step = 0.18
    i = 0
    at = 0.0
    while at < seconds:
        place(out, pluck(hz(notes[i % 8]) * (1 + 0.004 * np.sin(i * 0.7)), 0.45) * 0.5, at)
        if i % 4 == 0:
            place(out, kick(0.4, 0.4) * 0.5, at)
        if i % 2 == 1:
            place(out, hat() * 0.7, at)
        at += step
        i += 1
    out = out[: int(seconds * RATE)]
    out += sub_drone(hz("A1"), seconds) * 0.35 * np.linspace(0.2, 1.0, len(out))
    return fade(reverb(out, 0.25), 0.2, 1.5)


def morning(seconds):
    """Cold and thin: a high pad and a few single notes."""
    out = np.zeros(int(seconds * RATE) + RATE * 3)
    place(out, pad([hz("E4"), hz("B4")], seconds, 1400, 0.004) * 0.6, 0)
    for i, n in enumerate(["B4", "G4", "E4", "F#4", "B3", "E4"]):
        place(out, piano(hz(n), 3.0, 0.45), 0.6 + i * 2.4)
    return fade(reverb(out[: int(seconds * RATE)], 0.5), 0.8, 2.0)


def day_after_day(seconds):
    """A steady piano ostinato with a soft pulse that slowly gathers strength."""
    out = np.zeros(int(seconds * RATE) + RATE * 3)
    chords = [["D3", "A3", "F4"], ["A#2", "F3", "D4"], ["F3", "C4", "A4"], ["C3", "G3", "E4"]]
    beat = 0.42
    n = int(seconds / beat)
    for b in range(n):
        chord = chords[(b // 8) % 4]
        grow = b / max(n - 1, 1)
        note = chord[[0, 1, 2, 1][b % 4]]
        place(out, piano(hz(note), 1.6, 0.4 + 0.2 * grow), b * beat)
        if b % 8 == 0:
            place(out, pad([hz(x) for x in chord], beat * 8 + 0.5, 800) * (0.3 + 0.4 * grow), b * beat)
        if b % 2 == 0 and grow > 0.3:
            place(out, kick(0.5, 0.6) * 0.45 * grow, b * beat)
    return fade(reverb(out[: int(seconds * RATE)], 0.35), 0.3, 2.0)


def quieter(seconds, chord_at):
    """Warm and open: major piano and strings, ending on a held chord at the title."""
    out = np.zeros(int(seconds * RATE) + RATE * 4)
    chords = [["C3", "G3", "E4"], ["G2", "D3", "B3"], ["A2", "E3", "C4"], ["F2", "C3", "A3"]]
    melody = ["E5", "D5", "C5", "G4", "A4", "C5", "F5", "E5"]
    bar = 2.8
    k = 0
    at = 0.0
    while at < chord_at - 0.5:
        chord = chords[k % 4]
        for i, n in enumerate(chord):
            place(out, piano(hz(n), 2.8, 0.4), at + i * 0.1)
        place(out, piano(hz(melody[(2 * k) % 8]), 2.4, 0.55), at + 0.7)
        place(out, piano(hz(melody[(2 * k + 1) % 8]), 2.4, 0.45), at + 1.9)
        place(out, strings(hz(chord[0]) * 2, bar + 0.3, 0.6) * 0.06 * min(1.0, k / 3.0), at)
        at += bar
        k += 1
    final = ["C3", "G3", "C4", "E4", "G4", "C5"]
    for i, n in enumerate(final):
        place(out, piano(hz(n), 6.0, 0.55), chord_at + i * 0.06)
        place(out, strings(hz(n), seconds - chord_at, 1.0) * 0.05, chord_at)
    return fade(reverb(out[: int(seconds * RATE)], 0.45), 0.3, 3.0)


# --- Sound effects --------------------------------------------------------------

def buzz():
    """A phone vibrating on a desk: two short buzzes."""
    out = np.zeros(int(1.2 * RATE))
    for k in range(2):
        t = t_axis(0.38)
        tone = np.sign(np.sin(2 * np.pi * 150 * t)) * (0.6 + 0.4 * np.sin(2 * np.pi * 24 * t))
        rattle = highpass(RNG.standard_normal(len(t)), 2500) * 0.15
        env = np.minimum(1, t / 0.02) * np.minimum(1, (0.38 - t) / 0.03)
        place(out, lowpass(tone + rattle, 1800) * env, 0.05 + k * 0.55)
    return out


def tap():
    t = t_axis(0.08)
    return highpass(RNG.standard_normal(len(t)), 1500) * np.exp(-t * 90) + np.sin(2 * np.pi * 900 * t) * np.exp(-t * 70) * 0.5


def pop():
    """The app disappears: a soft rising pop."""
    t = t_axis(0.3)
    f = 400 + 900 * t / 0.3
    return np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 14) * np.minimum(1, t / 0.005)


def whoosh():
    """The shadow appearing: filtered noise swelling and fading."""
    seconds = 1.6
    t = t_axis(seconds)
    noise = RNG.standard_normal(len(t))
    env = np.sin(np.pi * t / seconds) ** 2
    low = lowpass(noise, 500) * env
    return low + lowpass(highpass(noise, 300), 1500) * env * 0.3 + sub_drone(hz("A1"), seconds) * env * 0.4


def crack():
    """Glass cracking: sharp ticks spreading out, a low thud under them."""
    out = np.zeros(int(1.5 * RATE))
    for k in range(14):
        t = t_axis(0.05)
        click = highpass(RNG.standard_normal(len(t)), 3000) * np.exp(-t * 120)
        place(out, click * (1.0 - k / 16), 0.02 + k * 0.03 + RNG.uniform(0, 0.02))
    place(out, kick(0.6, 0.8) * 0.5, 0.0)
    return out


def clock():
    """A wall clock ticking: six ticks."""
    out = np.zeros(int(3.2 * RATE))
    for k in range(6):
        t = t_axis(0.05)
        place(out, highpass(RNG.standard_normal(len(t)), 2000) * np.exp(-t * 150) * (0.8 if k % 2 == 0 else 0.55), 0.05 + k * 0.5)
    return out


if __name__ == "__main__":
    # Cue lengths fit the scene windows of film.script (start -> next cue).
    to_ogg("night_desk", night_desk(17.6))      # 0.0  -> 17.4  (scene 1, at the desk)
    to_ogg("scroll", scroll(12.5))              # 17.4 -> 29.7  (scrolling into the night)
    to_ogg("morning", morning(15.2))            # 29.7 -> 44.8  (scene 2)
    to_ogg("day_after_day", day_after_day(17.6))  # 44.8 -> 62.2  (scene 3)
    to_ogg("quieter", quieter(25.0, 15.4))    # 62.2 -> end, chord on the closing line (~77.6)
    to_wav("buzz", buzz(), 0.8)
    to_wav("tap", tap(), 0.7)
    to_wav("pop", pop(), 0.7)
    to_wav("whoosh", whoosh(), 0.8)
    to_wav("crack", crack(), 0.9)
    to_wav("clock", clock(), 0.7)
    print("made music/*.ogg and sfx/*.wav")
