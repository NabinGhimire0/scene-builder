"""Original music and sound effects for "The Surprise Test", synthesised from
scratch (no samples, no recordings). Usage:
  python make_classroom_audio.py <film folder>
Music -> music/*.ogg (via ffmpeg), effects -> sfx/*.wav.
"""
import os
import subprocess
import sys

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

RATE = 44100
RNG = np.random.default_rng(11)


# --- Helpers -------------------------------------------------------------------------

def t_axis(seconds):
    return np.arange(int(seconds * RATE)) / RATE


def env(n, attack=0.005, release=0.1):
    e = np.ones(n)
    a = max(1, min(n, int(attack * RATE)))
    r = max(1, min(n, int(release * RATE)))
    e[:a] = np.linspace(0, 1, a)
    e[-r:] *= np.linspace(1, 0, r)
    return e


def lowpass(x, f, order=2):
    return sosfilt(butter(order, f, "low", fs=RATE, output="sos"), x)


def highpass(x, f, order=2):
    return sosfilt(butter(order, f, "high", fs=RATE, output="sos"), x)


def bandpass(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], "band", fs=RATE, output="sos"), x)


def saw(freq, t, harmonics=12):
    out = np.zeros_like(t)
    for k in range(1, harmonics + 1):
        out += np.sin(2 * np.pi * freq * k * t) / k
    return out * 0.6


def note_hz(name):
    names = {"C": -9, "C#": -8, "D": -7, "D#": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "A": 0, "A#": 1, "B": 2}
    return 440.0 * 2 ** ((names[name[:-1]] + (int(name[-1]) - 4) * 12) / 12)


def reverb(x, amount=0.25):
    out = x.copy()
    for delay, gain in [(0.029, 0.5), (0.037, 0.45), (0.041, 0.4), (0.053, 0.35), (0.071, 0.3)]:
        d = int(delay * RATE)
        y = np.zeros_like(x)
        y[d:] = x[:-d]
        for _ in range(4):
            y[d:] += y[:-d] * gain * 0.5
        out += y * amount * gain
    return out


def place(track, sound, at):
    i = int(at * RATE)
    if i < 0 or i >= len(track):
        return
    end = min(len(track), i + len(sound))
    track[i:end] += sound[: end - i]


def normalise(x, peak=0.85):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak


def write_wav(path, x):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    wavfile.write(path, RATE, (normalise(x) * 32767).astype(np.int16))


def write_ogg(path, x):
    tmp = path[:-4] + ".tmp.wav"
    write_wav(tmp, x)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libvorbis", "-q:a", "5", path], check=True)
    os.remove(tmp)


def fade_out(x, seconds):
    n = min(len(x), int(seconds * RATE))
    x[-n:] *= np.linspace(1, 0, n)
    return x


# --- Instruments -----------------------------------------------------------------------

def pluck(freq, seconds=0.35, bright=3000, decay=9):
    t = t_axis(seconds)
    return lowpass(saw(freq, t, 10) * np.exp(-t * decay), bright) * env(len(t), 0.002, 0.05)


def uke(freq, seconds=0.5):
    """Nylon-string pluck: Karplus-Strong."""
    n = int(seconds * RATE)
    period = max(2, int(RATE / freq))
    buf = RNG.uniform(-1, 1, period)
    out = np.zeros(n)
    for i in range(n):
        out[i] = buf[i % period]
        buf[i % period] = 0.497 * (buf[i % period] + buf[(i + 1) % period])
    return lowpass(out, 4000) * env(n, 0.001, 0.05)


def glock(freq, seconds=0.9):
    t = t_axis(seconds)
    x = np.sin(2 * np.pi * freq * t) + 0.4 * np.sin(2 * np.pi * freq * 2.76 * t) * np.exp(-t * 6) + 0.2 * np.sin(2 * np.pi * freq * 5.4 * t) * np.exp(-t * 12)
    return x * np.exp(-t * 3.5) * env(len(t), 0.001, 0.05)


def xylo(freq, seconds=0.25):
    t = t_axis(seconds)
    x = np.sin(2 * np.pi * freq * t) + 0.5 * np.sin(2 * np.pi * freq * 3.93 * t) * np.exp(-t * 30)
    return x * np.exp(-t * 16) * env(len(t), 0.001, 0.03)


def bass(freq, seconds, bright=900):
    t = t_axis(seconds)
    x = (np.sin(2 * np.pi * freq * t) + 0.4 * saw(freq, t, 6)) * np.exp(-t * 2.5)
    return lowpass(x, bright) * env(len(t), 0.004, 0.06)


def tuba(freq, seconds):
    t = t_axis(seconds)
    x = saw(freq, t, 8) * env(len(t), 0.02, 0.08)
    return lowpass(x, 700)


def kick():
    t = t_axis(0.35)
    f = 50 + 120 * np.exp(-t * 30)
    return np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 9)


def snare():
    t = t_axis(0.22)
    noise = highpass(RNG.standard_normal(len(t)), 1500) * np.exp(-t * 18)
    return noise * 0.6 + np.sin(2 * np.pi * 190 * t) * np.exp(-t * 25) * 0.5


def hat(open_hat=False):
    t = t_axis(0.18 if open_hat else 0.05)
    return highpass(RNG.standard_normal(len(t)), 7000) * np.exp(-t * (14 if open_hat else 70)) * 0.35


def woodblock(high=True):
    t = t_axis(0.12)
    f = 1100 if high else 800
    return (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * f * 2.3 * t)) * np.exp(-t * 45)


def clap():
    t = t_axis(0.18)
    burst = np.zeros_like(t)
    for d in (0.0, 0.011, 0.023):
        i = int(d * RATE)
        burst[i:] += np.exp(-t[: len(t) - i] * 60)
    return bandpass(RNG.standard_normal(len(t)), 800, 3000) * burst * 0.5


def madal(low=True):
    t = t_axis(0.3)
    f = (95 if low else 260) * (1 + 0.4 * np.exp(-t * 40))
    x = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * (8 if low else 16))
    return x + highpass(RNG.standard_normal(len(t)), 2000) * np.exp(-t * 60) * 0.2


def brass(freq, seconds, bright=2200):
    t = t_axis(seconds)
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t) * np.clip(t * 3, 0, 1)
    return lowpass(saw(freq, t * vib, 14), bright) * env(len(t), 0.03, 0.12)


def flute(freq, seconds):
    t = t_axis(seconds)
    tone = np.sin(2 * np.pi * freq * t + 0.6 * np.sin(2 * np.pi * 5 * t) * np.clip(t * 2, 0, 1))
    breath = bandpass(RNG.standard_normal(len(t)), freq, min(freq * 3, 18000)) * 0.05
    return (tone + 0.2 * np.sin(4 * np.pi * freq * t) + breath) * env(len(t), 0.04, 0.08)


def strings(freq, seconds):
    t = t_axis(seconds)
    x = sum(saw(freq * (1 + d), t, 10) for d in (-0.004, 0.0, 0.005)) / 3
    return lowpass(x, 1800) * env(len(t), 0.25, 0.3)


# --- Music -------------------------------------------------------------------------------

def morning(seconds):
    """Bright school-morning theme: ukulele strum, glockenspiel tune, claps. C major, 112 bpm."""
    beat = 60 / 112
    track = np.zeros(int((seconds + 2) * RATE))
    chords = [["C4", "E4", "G4", "C5"], ["A3", "E4", "A4", "C5"], ["F3", "C4", "F4", "A4"], ["G3", "D4", "G4", "B4"]]
    roots = ["C3", "A2", "F2", "G2"]
    tune = [("E5", 1), ("G5", 0.5), ("E5", 0.5), ("C5", 1), ("D5", 1), ("E5", 0.5), ("F5", 0.5), ("E5", 1), ("D5", 1), (None, 1),
            ("C5", 0.5), ("D5", 0.5), ("E5", 1), ("A5", 1), ("G5", 1.5), ("E5", 0.5), ("D5", 1), ("C5", 1), (None, 1)]
    t, bar = 0.0, 0
    while t < seconds:
        chord = chords[bar % 4]
        for b, strum in enumerate([1, 0.5, 0.5, 1, 0.5, 0.5]):
            at = t + [0, 1, 1.5, 2, 3, 3.5][b] * beat
            for k, n in enumerate(chord):
                place(track, uke(note_hz(n), 0.6) * 0.22, at + k * 0.012)
        place(track, bass(note_hz(roots[bar % 4]), beat * 1.8) * 0.5, t)
        place(track, bass(note_hz(roots[bar % 4]), beat * 1.8) * 0.4, t + 2 * beat)
        place(track, clap() * 0.35, t + beat)
        place(track, clap() * 0.35, t + 3 * beat)
        t += 4 * beat
        bar += 1
    t = 4 * beat
    while t < seconds - 2:
        for n, length in tune:
            if t >= seconds - 2:
                break
            if n:
                place(track, glock(note_hz(n), 0.9) * 0.3, t)
            t += length * beat
    track = reverb(track, 0.15)[: int(seconds * RATE)]
    return fade_out(track, 2.0)


def quiz(seconds):
    """Game-show thinking music: tick-tock woodblocks and pizzicato, A minor, 120 bpm."""
    beat = 60 / 120
    track = np.zeros(int((seconds + 2) * RATE))
    line = ["A3", "C4", "E4", "C4", "D4", "F4", "A4", "F4", "E4", "G#4", "B4", "G#4", "A4", "E4", "C4", "E4"]
    t, i = 0.0, 0
    while t < seconds:
        place(track, woodblock(i % 2 == 0) * 0.45, t)
        place(track, pluck(note_hz(line[i % len(line)]), 0.3, 2200, 12) * 0.5, t)
        if i % 4 == 0:
            place(track, bass(note_hz(["A2", "D2", "E2", "A2"][(i // 16) % 4]), beat * 1.8) * 0.5, t)
        if i % 8 == 6:
            place(track, glock(note_hz("E6"), 0.4) * 0.15, t + beat * 0.5)
        t += beat
        i += 1
    return fade_out(reverb(track, 0.12)[: int(seconds * RATE)], 1.5)


def chaos(seconds):
    """Teacher's-gone funk: drums, slap bass, brass stabs. G minor, 124 bpm."""
    beat = 60 / 124
    track = np.zeros(int((seconds + 2) * RATE))
    bassline = ["G2", "G2", "G3", "G2", "A#2", "C3", "D3", "F3"]
    stabs = [["G4", "A#4", "D5"], ["F4", "A4", "C5"], ["D#4", "G4", "A#4"], ["F4", "A4", "C5"]]
    t, bar = 0.0, 0
    while t < seconds:
        for b in range(4):
            at = t + b * beat
            place(track, kick() * 0.9, at)
            if b % 2 == 1:
                place(track, snare() * 0.6, at)
                place(track, clap() * 0.3, at)
            place(track, hat() * 0.2, at + beat * 0.5)
        for i, n in enumerate(bassline):
            place(track, bass(note_hz(n), beat * 0.4, 1400) * 0.75, t + i * beat * 0.5)
        for at in [beat * 1.5, beat * 3.5]:
            place(track, sum(brass(note_hz(n), 0.16, 3000) for n in stabs[bar % 4]) * 0.25, t + at)
        if bar % 4 == 3:
            for k, n in enumerate(["G5", "F5", "D5", "C5", "A#4", "G4"]):
                place(track, xylo(note_hz(n)) * 0.3, t + 2 * beat + k * beat / 3)
        t += 4 * beat
        bar += 1
    return fade_out(reverb(track, 0.1)[: int(seconds * RATE)], 1.0)


def test_music(seconds):
    """Exam tension: a ticking clock, a heartbeat bass and a slow string line. D minor, 90 bpm."""
    beat = 60 / 90
    track = np.zeros(int((seconds + 3) * RATE))
    t, i = 0.0, 0
    while t < seconds:
        place(track, woodblock(i % 2 == 0) * 0.25, t)
        if i % 2 == 0:
            place(track, kick() * 0.35, t)
            place(track, kick() * 0.2, t + 0.22)
        t += beat
        i += 1
    line = [("D4", 4), ("C#4", 4), ("D4", 4), ("F4", 2), ("E4", 2), ("D4", 4), ("A3", 4), ("A#3", 4), ("A3", 4)]
    t = 0.0
    while t < seconds:
        for n, length in line:
            if t >= seconds:
                break
            place(track, strings(note_hz(n), length * beat) * 0.18, t)
            place(track, strings(note_hz(n) / 2, length * beat) * 0.12, t)
            t += length * beat
    for k in range(int(seconds / (beat * 8))):
        place(track, pluck(note_hz("A5"), 0.3, 5000, 14) * 0.12, k * beat * 8 + beat * 6.5)
    return fade_out(reverb(track, 0.25)[: int(seconds * RATE)], 1.0)


def chase(seconds):
    """Frantic frog chase: galloping tuba, xylophone runs, snare rolls. F major, 168 bpm."""
    beat = 60 / 168
    track = np.zeros(int((seconds + 2) * RATE))
    roots = ["F2", "C3", "F2", "C3", "D2", "A2", "C3", "G2"]
    run = ["F5", "G5", "A5", "C6", "A5", "G5", "F5", "C5", "D5", "F5", "E5", "G5", "F5", "A5", "C6", "F6"]
    t, i = 0.0, 0
    while t < seconds:
        place(track, tuba(note_hz(roots[(i // 2) % len(roots)]), beat * 0.45) * 0.6, t)
        place(track, (snare() * 0.35 if i % 2 else kick() * 0.6), t)
        place(track, hat() * 0.2, t + beat * 0.5)
        place(track, xylo(note_hz(run[i % len(run)])) * 0.35, t)
        place(track, xylo(note_hz(run[(i + 3) % len(run)])) * 0.2, t + beat * 0.5)
        t += beat
        i += 1
    return fade_out(reverb(track, 0.08)[: int(seconds * RATE)], 0.6)


def finale(seconds):
    """Happy Nepali-folk finale: madal, flute, bass, ending on a big chord at seconds - 2.5. G major, 128 bpm."""
    beat = 60 / 128
    track = np.zeros(int((seconds + 3) * RATE))
    melody = [("B5", 0.5), ("A5", 0.5), ("G5", 1), ("D5", 1), ("G5", 0.5), ("A5", 0.5), ("B5", 1), ("D6", 1), ("B5", 1), (None, 1),
              ("C6", 0.5), ("B5", 0.5), ("A5", 1), ("E5", 1), ("F#5", 0.5), ("G5", 0.5), ("A5", 2), (None, 1)]
    chords = [("G2", "D3"), ("C3", "G3"), ("D3", "A3"), ("G2", "D3")]
    end = seconds - 2.5
    t, bar = 0.0, 0
    while t < end - 0.2:
        root, fifth = chords[bar % 4]
        for b in range(4):
            at = t + b * beat
            if at >= end - 0.1:
                break
            place(track, bass(note_hz(root if b % 2 == 0 else fifth), beat * 0.8) * 0.6, at)
            place(track, madal(b % 2 == 0) * 0.5, at)
            place(track, madal(False) * 0.3, at + beat * 0.5)
            place(track, clap() * 0.25, at + (beat if b % 2 else 0) * 0)
        t += 4 * beat
        bar += 1
    t = beat * 2
    while t < end - 0.5:
        for n, length in melody:
            if t >= end - 0.5:
                break
            if n:
                place(track, flute(note_hz(n), length * beat * 0.95) * 0.32, t)
            t += length * beat
    for n in ["G3", "B3", "D4", "G4", "B4", "D5"]:
        place(track, brass(note_hz(n), 2.4) * 0.2, end)
    place(track, kick(), end)
    place(track, glock(note_hz("G6"), 1.5) * 0.3, end)
    return lowpass(reverb(track, 0.18), 9000)[: int(seconds * RATE)]


# --- Sound effects ----------------------------------------------------------------------------

def snore():
    t = t_axis(2.6)
    inhale = (t < 1.3) * np.sin(np.pi * np.clip(t / 1.3, 0, 1))
    exhale = (t >= 1.3) * np.sin(np.pi * np.clip((t - 1.3) / 1.3, 0, 1))
    rattle = (1 + 0.8 * np.sin(2 * np.pi * 32 * t)) * lowpass(RNG.standard_normal(len(t)), 500)
    whistle = np.sin(2 * np.pi * (900 + 300 * (t - 1.3)) * t) * 0.15
    return rattle * inhale + whistle * exhale


def dun():
    out = np.zeros(int(3.6 * RATE))
    for at, length in [(0.0, 0.35), (0.45, 0.35), (0.95, 2.4)]:
        hit = sum(brass(note_hz(n), length) for n in ["D3", "F3", "A3", "D4"]) * 0.3
        hit += brass(note_hz("D2"), length) * 0.5
        place(out, hit, at)
        place(out, kick() * 0.8, at)
    return reverb(out, 0.35)


def boing():
    t = t_axis(1.0)
    f = 160 * (1 + 0.6 * np.exp(-t * 3) * np.sin(2 * np.pi * 9 * t)) + 120 * np.exp(-t * 6)
    return np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 3)


def voice_burst(pitch, seconds, vowel=(800, 1250, 2600), breathy=0.15, glide=0.0):
    """A short sung vowel from a glottal pulse train through three formant filters."""
    t = t_axis(seconds)
    f = pitch * (1 + glide * t / seconds) * (1 + 0.02 * np.sin(2 * np.pi * 6 * t))
    phase = np.cumsum(f) / RATE
    pulses = (np.mod(phase, 1.0) < 0.08).astype(float) - 0.08
    src = pulses + breathy * RNG.standard_normal(len(t))
    out = np.zeros_like(t)
    for k, fc in enumerate(vowel):
        out += bandpass(src, fc * 0.85, fc * 1.15) * (1.0, 0.6, 0.25)[k]
    return out * env(len(t), 0.01, 0.04)


def laugh():
    """A classroom of children giggling: layered 'ha-ha-ha' voices."""
    out = np.zeros(int(2.8 * RATE))
    for v in range(9):
        pitch = RNG.uniform(260, 420)
        start = RNG.uniform(0, 0.35)
        vowel = (RNG.uniform(850, 1050), RNG.uniform(1350, 1700), RNG.uniform(2700, 3200))
        n = int(RNG.integers(5, 9))
        for k in range(n):
            length = RNG.uniform(0.09, 0.14)
            p = pitch * (1.15 - 0.3 * k / n)
            place(out, voice_burst(p, length, vowel, 0.35) * (0.9 - 0.06 * k), start + k * RNG.uniform(0.17, 0.22))
    out += bandpass(RNG.standard_normal(len(out)), 1500, 6000) * 0.02 * np.exp(-t_axis(2.8) * 0.8)
    return reverb(out, 0.25) * env(len(out), 0.02, 0.5)


def aww():
    """Children going 'awww': long falling vowels."""
    out = np.zeros(int(2.0 * RATE))
    for v in range(8):
        pitch = RNG.uniform(300, 400)
        place(out, voice_burst(pitch, RNG.uniform(1.2, 1.6), (700, 1050, 2600), 0.3, glide=-0.3), RNG.uniform(0, 0.2))
    return reverb(out, 0.3)


def bell():
    """A brass hand bell rung back and forth."""
    out = np.zeros(int(2.8 * RATE))
    ratios = [0.5, 1.0, 1.19, 1.5, 2.0, 2.52, 3.0, 4.07]
    for k in range(12):
        t = t_axis(1.0)
        f0 = 1180 if k % 2 == 0 else 1150
        hit = sum(np.sin(2 * np.pi * f0 * r * t) * np.exp(-t * (2 + r * 2)) / (1 + i * 0.4) for i, r in enumerate(ratios))
        place(out, hit * (0.9 if k < 10 else 0.6), k * 0.16)
    return reverb(out, 0.3) * env(len(out), 0.001, 0.4)


def steps(count, spacing, heel=True, grow=True):
    out = np.zeros(int((count * spacing + 0.4) * RATE))
    for k in range(count):
        t = t_axis(0.12)
        click = bandpass(RNG.standard_normal(len(t)), 1800 if heel else 300, 6000 if heel else 1500) * np.exp(-t * (60 if heel else 35))
        thud = np.sin(2 * np.pi * 110 * t) * np.exp(-t * 40) * 0.4
        place(out, (click + thud) * ((0.4 + 0.6 * k / count) if grow else 1.0), k * spacing + RNG.uniform(-0.01, 0.01))
    return reverb(out, 0.25)


def ding():
    t = t_axis(1.2)
    a = glock(note_hz("E6"), 1.2)
    b = np.zeros_like(a)
    place(b, glock(note_hz("A6"), 1.0), 0.12)
    return (a + b) * 0.8


def tick():
    out = np.zeros(int(3.0 * RATE))
    for k in range(6):
        place(out, woodblock(k % 2 == 0) * 0.6, k * 0.5)
    return out


def chalk():
    t = t_axis(2.2)
    noise = RNG.standard_normal(len(t))
    strokes = np.clip(np.sin(2 * np.pi * 2.3 * t) * 1.5, 0, 1) * (1 + 0.5 * np.sin(2 * np.pi * 37 * t))
    squeak = np.sin(2 * np.pi * (2200 + 300 * np.sin(2 * np.pi * 1.1 * t)) * t) * 0.05 * (t > 1.5) * (t < 1.7)
    return bandpass(noise, 2500, 9000) * strokes * 0.6 + squeak


def fold():
    out = np.zeros(int(1.2 * RATE))
    for k in range(9):
        t = t_axis(0.08)
        place(out, bandpass(RNG.standard_normal(len(t)), 1500, 9000) * np.exp(-t * 40), k * 0.11 + RNG.uniform(0, 0.04))
    return out


def whoosh():
    t = t_axis(1.0)
    noise = RNG.standard_normal(len(t))
    out = np.zeros_like(t)
    for i in range(0, len(t), 1024):
        c = 400 + 3000 * (i / len(t))
        out[i:i + 1024] = bandpass(noise[i:i + 1024], c * 0.7, c * 1.4)
    return out * np.sin(np.pi * t / 1.0) ** 2


def sad_trombone():
    out = np.zeros(int(3.2 * RATE))
    for k, (n, length) in enumerate([("D#4", 0.5), ("D4", 0.5), ("C#4", 0.5), ("C4", 1.6)]):
        t = t_axis(length)
        wah = 0.6 + 0.4 * np.sin(np.pi * np.clip(t / length, 0, 1))
        tone = brass(note_hz(n) / 2, length, 1500) * wah
        if length > 1:
            tone *= 1 + 0.35 * np.sin(2 * np.pi * 6 * t)
        place(out, tone, k * 0.55)
    return reverb(out, 0.25)


def ribbit():
    out = np.zeros(int(0.8 * RATE))
    for at, length in [(0.0, 0.12), (0.2, 0.18)]:
        t = t_axis(length)
        pulses = (np.sin(2 * np.pi * 38 * t) > 0.3).astype(float)
        tone = np.sin(2 * np.pi * (520 + 120 * t / length) * t) + 0.5 * np.sin(2 * np.pi * 1300 * t)
        place(out, bandpass(tone * pulses, 300, 2200) * env(len(t), 0.005, 0.03), at)
    return out


def clink():
    t = t_axis(0.9)
    x = sum(np.sin(2 * np.pi * f * t) * np.exp(-t * d) for f, d in [(2350, 8), (3410, 10), (5120, 14), (1710, 7)])
    rattle = np.zeros_like(t)
    place(rattle, x[: int(0.4 * RATE)] * 0.4, 0.09)
    return x + rattle


def paper():
    t = t_axis(0.6)
    return bandpass(RNG.standard_normal(len(t)), 1200, 8000) * np.sin(np.pi * t / 0.6) ** 1.5


def stomach():
    t = t_axis(1.6)
    f = 70 + 30 * np.sin(2 * np.pi * 1.7 * t) + 40 * np.sin(2 * np.pi * 0.6 * t)
    tone = np.sin(2 * np.pi * np.cumsum(f) / RATE)
    gurgle = (1 + np.sin(2 * np.pi * (8 + 6 * t) * t))
    return lowpass(tone * gurgle + lowpass(RNG.standard_normal(len(t)), 300) * 0.4, 600) * env(len(t), 0.1, 0.4)


def door():
    t = t_axis(1.4)
    f = 300 + 200 * np.sin(2 * np.pi * 0.7 * t)
    creak = bandpass(np.sign(np.sin(2 * np.pi * np.cumsum(f) / RATE)) * (np.sin(2 * np.pi * 23 * t) > 0), 400, 2500) * 0.4
    out = creak * env(len(t), 0.05, 0.2)
    latch = np.zeros_like(t)
    place(latch, bandpass(RNG.standard_normal(int(0.05 * RATE)), 1000, 5000) * 0.8, 1.15)
    return out + latch


def main():
    folder = sys.argv[1]
    sfx = os.path.join(folder, "sfx")
    music = os.path.join(folder, "music")
    effects = [("snore", snore), ("dun", dun), ("boing", boing), ("laugh", laugh), ("aww", aww), ("bell", bell),
               ("footsteps", lambda: steps(8, 0.42)), ("run", lambda: steps(9, 0.17, heel=False, grow=False)), ("ding", ding),
               ("tick", tick), ("chalk", chalk), ("fold", fold), ("whoosh", whoosh), ("sad_trombone", sad_trombone),
               ("ribbit", ribbit), ("clink", clink), ("paper", paper), ("stomach", stomach), ("door", door)]
    for name, fn in effects:
        write_wav(os.path.join(sfx, name + ".wav"), fn())
    os.makedirs(music, exist_ok=True)
    for name, fn, seconds in [("morning", morning, 36.0), ("quiz", quiz, 21.0), ("chaos", chaos, 29.5),
                              ("test", test_music, 23.5), ("chase", chase, 20.0), ("finale", finale, 17.4)]:
        write_ogg(os.path.join(music, name + ".ogg"), fn(seconds))
    print("AUDIO OK")


main()
