"""Builds the props for "The Surprise Test" with Blender and exports them as .glb:
paper_plane, tiffin (steel lunch box), frog, test_papers (a stack),
test_paper (one sheet), bell (brass hand bell), book (open textbook).
Run:  python make_classroom_props.py -- <models folder>
"""
import math
import os
import sys

import bpy
import bmesh

OUT = sys.argv[sys.argv.index("--") + 1]


def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def material(name, color, rough=0.6, metal=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*color, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    return m


def mesh_object(name, verts, faces, mat):
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    return obj


def last(mat=None, smooth=False):
    obj = bpy.context.object
    if mat:
        obj.data.materials.append(mat)
    if smooth:
        bpy.ops.object.shade_smooth()
    return obj


def join_all(name):
    bpy.ops.object.select_all(action="SELECT")
    objs = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    bpy.context.view_layer.objects.active = objs[0]
    bpy.ops.object.join()
    bpy.context.object.name = name
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)


def export(name):
    path = os.path.join(OUT, name)
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB", export_apply=True)
    print("EXPORTED", path)


def paper_mat():
    return material("Paper", (0.96, 0.95, 0.9), rough=0.85)


def ink_mat():
    return material("Ink", (0.12, 0.16, 0.42), rough=0.7)


# --- Props ---------------------------------------------------------------------------

def paper_plane():
    """Classic dart: two wings and a keel, nose pointing +Y (Blender) = forward."""
    paper = paper_mat()
    s = 0.32  # length
    nose = (0, s / 2, 0.06)
    tail_c = (0, -s / 2, 0.06)
    keel_b = (0, -s / 2, 0.015)
    left = (-0.11, -s / 2, 0.075)
    right = (0.11, -s / 2, 0.075)
    verts = [nose, tail_c, left, right, keel_b]
    faces = [(0, 2, 1), (0, 1, 3), (0, 1, 4)]
    obj = mesh_object("Plane", verts, faces, paper)
    mod = obj.modifiers.new("Solid", "SOLIDIFY")
    mod.thickness = 0.002
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_apply(modifier="Solid")
    # Scribbled answers on the wing.
    ink = ink_mat()
    for i in range(3):
        y = -0.05 - i * 0.03
        bpy.ops.mesh.primitive_cube_add(size=1, location=(0.045, y, 0.07 + 0.002))
        o = last(ink)
        o.scale = (0.05, 0.004, 0.001)
        o.rotation_euler = (0, -0.13, 0)


def tiffin():
    """Nepali steel tiffin: three stacked round tins in a clip frame, with a handle."""
    steel = material("Steel", (0.82, 0.83, 0.85), rough=0.18, metal=1.0)
    dark = material("SteelDark", (0.55, 0.56, 0.58), rough=0.3, metal=1.0)
    r = 0.075
    for i in range(3):
        z = i * 0.062
        bpy.ops.mesh.primitive_cylinder_add(vertices=48, radius=r, depth=0.058, location=(0, 0, z + 0.029))
        last(steel, True)
        bpy.ops.mesh.primitive_torus_add(major_radius=r + 0.002, minor_radius=0.003, location=(0, 0, z + 0.058))
        last(dark, True)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=r * 0.98, location=(0, 0, 0.186))
    lid = last(steel, True)
    lid.scale = (1, 1, 0.18)
    for side in (-1, 1):
        bpy.ops.mesh.primitive_cube_add(size=1, location=(side * (r + 0.006), 0, 0.12))
        bar = last(dark)
        bar.scale = (0.006, 0.018, 0.25)
    bpy.ops.mesh.primitive_torus_add(major_radius=r + 0.006, minor_radius=0.005, location=(0, 0, 0.245), rotation=(0, math.pi / 2, 0))
    handle = last(dark, True)
    handle.scale = (1, 1, 1)
    # Keep only the top half of the handle ring.
    bpy.context.view_layer.objects.active = handle
    bpy.ops.object.mode_set(mode="EDIT")
    bm = bmesh.from_edit_mesh(handle.data)
    gone = [v for v in bm.verts if v.co.x > 0.0]  # local x = world z after the 90° turn
    bmesh.ops.delete(bm, geom=gone, context="VERTS")
    bmesh.update_edit_mesh(handle.data)
    bpy.ops.object.mode_set(mode="OBJECT")
    handle.location.z = 0.2


def frog():
    """A round, friendly cartoon frog, about 17 cm long, facing +Y."""
    green = material("FrogGreen", (0.13, 0.48, 0.07), rough=0.35)
    belly = material("FrogBelly", (0.78, 0.86, 0.45), rough=0.45)
    white = material("EyeWhite", (0.97, 0.97, 0.95), rough=0.2)
    black = material("Pupil", (0.03, 0.03, 0.03), rough=0.1)
    pink = material("Mouth", (0.75, 0.25, 0.3), rough=0.5)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.07, location=(0, 0, 0.055))
    body = last(green, True)
    body.scale = (1.1, 1.25, 0.75)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.055, location=(0, 0.02, 0.04))
    b = last(belly, True)
    b.scale = (1.0, 1.25, 0.55)
    for side in (-1, 1):
        bpy.ops.mesh.primitive_uv_sphere_add(radius=0.03, location=(side * 0.04, 0.05, 0.11))
        last(green, True)
        bpy.ops.mesh.primitive_uv_sphere_add(radius=0.024, location=(side * 0.042, 0.064, 0.118))
        last(white, True)
        bpy.ops.mesh.primitive_uv_sphere_add(radius=0.012, location=(side * 0.043, 0.084, 0.122))
        last(black, True)
        # Folded back legs and little front feet.
        bpy.ops.mesh.primitive_uv_sphere_add(radius=0.035, location=(side * 0.075, -0.045, 0.03))
        leg = last(green, True)
        leg.scale = (0.8, 1.5, 0.7)
        bpy.ops.mesh.primitive_uv_sphere_add(radius=0.02, location=(side * 0.09, 0.0, 0.008))
        foot = last(green, True)
        foot.scale = (1.4, 2.2, 0.4)
        bpy.ops.mesh.primitive_uv_sphere_add(radius=0.014, location=(side * 0.05, 0.075, 0.008))
        f = last(green, True)
        f.scale = (1.3, 1.6, 0.45)
    bpy.ops.mesh.primitive_torus_add(major_radius=0.038, minor_radius=0.004, location=(0, 0.06, 0.07), rotation=(math.radians(-70), 0, 0))
    smile = last(pink, True)
    smile.scale = (1, 0.6, 1)


def sheet(location, rotation=0.0, lines=True):
    paper = bpy.data.materials.get("Paper") or paper_mat()
    ink = bpy.data.materials.get("Ink") or ink_mat()
    bpy.ops.mesh.primitive_cube_add(size=1, location=location, rotation=(0, 0, rotation))
    o = last(paper)
    o.scale = (0.21, 0.297, 0.0015)
    if lines:
        # Title line and question lines.
        x, y, z = location
        for i in range(9):
            w = 0.12 if i == 0 else 0.16 - 0.03 * (i % 3)
            dy = 0.11 - i * 0.026
            px = x + math.cos(rotation) * (-0.085 + w / 2) - math.sin(rotation) * dy
            py = y + math.sin(rotation) * (-0.085 + w / 2) + math.cos(rotation) * dy
            bpy.ops.mesh.primitive_cube_add(size=1, location=(px, py, z + 0.0009), rotation=(0, 0, rotation))
            l = last(ink)
            l.scale = (w, 0.004 if i else 0.007, 0.0004)


def test_paper():
    sheet((0, 0, 0.001))


def test_papers():
    for i in range(14):
        sheet((0.003 * math.sin(i * 2.1), 0.003 * math.cos(i * 1.7), 0.001 + i * 0.0032), rotation=0.04 * math.sin(i * 1.3), lines=(i == 13))
    clip = material("Clip", (0.15, 0.15, 0.17), rough=0.3, metal=0.8)
    bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0.14, 0.046))
    c = last(clip)
    c.scale = (0.05, 0.018, 0.012)


def bell():
    """Brass school hand bell with a wooden handle."""
    brass = material("Brass", (0.85, 0.62, 0.22), rough=0.22, metal=1.0)
    wood = material("Wood", (0.36, 0.2, 0.09), rough=0.55)
    bpy.ops.mesh.primitive_cone_add(vertices=48, radius1=0.075, radius2=0.035, depth=0.1, location=(0, 0, 0.05), end_fill_type="NOTHING")
    cone = last(brass, True)
    mod = cone.modifiers.new("Solid", "SOLIDIFY")
    mod.thickness = 0.004
    bpy.context.view_layer.objects.active = cone
    bpy.ops.object.modifier_apply(modifier="Solid")
    bpy.ops.mesh.primitive_torus_add(major_radius=0.074, minor_radius=0.006, location=(0, 0, 0.002))
    last(brass, True)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.036, location=(0, 0, 0.1))
    dome = last(brass, True)
    dome.scale = (1, 1, 0.5)
    bpy.ops.mesh.primitive_cylinder_add(vertices=24, radius=0.016, depth=0.12, location=(0, 0, 0.17))
    last(wood, True)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.022, location=(0, 0, 0.235))
    last(wood, True)


def book():
    """Open textbook: two curved page blocks on a blue cover."""
    cover = material("Cover", (0.12, 0.35, 0.65), rough=0.5)
    paper = paper_mat()
    ink = ink_mat()
    bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0.003))
    c = last(cover)
    c.scale = (0.42, 0.29, 0.006)
    for side in (-1, 1):
        bpy.ops.mesh.primitive_cube_add(size=1, location=(side * 0.102, 0, 0.014))
        p = last(paper)
        p.scale = (0.2, 0.27, 0.016)
        p.rotation_euler = (0, side * -0.06, 0)
        for i in range(8):
            bpy.ops.mesh.primitive_cube_add(size=1, location=(side * 0.102, 0.1 - i * 0.026, 0.0226 + 0.006 * (0.2 - abs(side * 0.102) * 0)))
            l = last(ink)
            l.scale = (0.15, 0.004, 0.0005)
            l.rotation_euler = (0, side * -0.06, 0)


def main():
    os.makedirs(OUT, exist_ok=True)
    for name, build in [("paper_plane", paper_plane), ("tiffin", tiffin), ("frog", frog), ("test_paper", test_paper),
                        ("test_papers", test_papers), ("bell", bell), ("book", book)]:
        reset()
        build()
        join_all(name.replace("_", " ").title())
        export(name + ".glb")


main()
