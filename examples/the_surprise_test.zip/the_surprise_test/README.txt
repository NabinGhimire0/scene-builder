THE SURPRISE TEST - a 6-minute Scene Builder classroom comedy (5:47)
=================================================================

Monday morning, Class 6. Bunty has never done his homework and always has an
excuse. Golu thinks every hour is lunch time. Pinky has read page forty-two
nine times. Then Sharma Miss walks in with three terrible words:
"SURPRISE... TEST..."

Excuses, a paper-plane "air mail", a teacher impression that goes very wrong,
a frog in a tiffin box, a classroom chase... and a final surprise that nobody
saw coming. Least of all Sharma Miss.

HOW TO WATCH
1. In Scene Builder press Script -> Open... -> choose the_surprise_test.zip
   (or "Package folder..." and pick this folder).
2. Leave "Speak dialogue" ticked (the script turns voices on) and press
   Build Film, then Watch. The first build takes a little longer while the
   voices are made; after that they are cached.
3. Export Video -> MP4 to make the video (needs FFmpeg for the music and sounds).
   Needs Scene Builder 1.5 or newer.

THE STORY (11 scenes)
 1  Monday morning     Bunty runs in late; the "My Best Friend" essay (one word)
 2  Act intelligent    Kanchha Dai rings the bell; the class tries to look clever
 3  Surprise!          The surprise test; "My dog ate my homework"
 4  Quick revision     Gravity, and ten momos minus five
 5  Air mail           A paper plane full of answers lands on the wrong desk
 6  Nobody moves       Sharma Miss leaves. Bunty becomes Sharma Miss. Dance break.
 7  Behind you         She is back. She is right behind him.
 8  The test           Six papers, one hungry Golu, one tiffin that ribbits
 9  Frog panic         Bhyagute the frog takes over the classroom
10  The real surprise  The Principal arrives with a test... for the TEACHERS
11  Freedom            Lunch time!

CAST
Sharma Miss (teacher), Bunty, Golu, Pinky, Rita, Sonu, Mintu (Class 6),
Kanchha Dai (school peon), Principal Sir - and Bhyagute the frog.

WHAT'S INSIDE
film.script              the screenplay: 11 scenes, 9 characters, 97 camera shots
models/paper_plane.glb   Bunty's "air mail"                    (made in Blender)
models/tiffin.glb        Golu's three-tier steel tiffin box    (made in Blender)
models/frog.glb          Bhyagute the frog                     (made in Blender)
models/test_papers.glb   a clipped stack of test papers        (made in Blender)
models/test_paper.glb    one test sheet for each desk          (made in Blender)
models/bell.glb          Kanchha Dai's brass hand bell         (made in Blender)
models/book.glb          Pinky's open textbook                 (made in Blender)
music/morning.ogg        bright ukulele and glockenspiel school-morning theme
music/quiz.ogg           tick-tock game-show thinking music
music/chaos.ogg          teacher's-gone funk for the dance break
music/test.ogg           exam tension: ticking clock and slow strings
music/chase.ogg          galloping frog-chase music with xylophone
music/finale.ogg         happy folk finale with madal and flute
sfx/*.wav                school bell, footsteps, running feet, dun-dun-DUUN,
                         kids laughing, "awww", quiz ding, ticking clock, chalk,
                         paper fold, whoosh, boing, sad trombone, ribbit,
                         tiffin clink, paper rustle, tummy rumble, door, snore
tools/                   the Blender and audio scripts that made the files above

All models, music and sounds are original, made for this film; use them freely.

HOW THE CLASSROOM IS USED
The Classroom location has 12 desks with chairs, in 4 columns and 3 rows:
  front row  (nearest the board):  chair 1, chair 4, chair 7, chair 10
  middle row:                      chair 2, chair 5, chair 8, chair 11
  back row:                        chair 3, chair 6, chair 9, chair 12
Pinky sits on chair 4, Rita on 7, Sonu on 2, Bunty on 5 (later the front
bench, chair 10), Golu on 8, Mintu on 9. Each chair has a "school desk" with
the same number in front of it. The door is in the right-hand wall, level with
the middle row, at (5.6, 2.25) - every entrance and exit uses it.

MAKE IT YOURS
- Change names, clothes and colours in the CAST section (school uniform is
  white and navy; Sharma Miss wears #7b1e2e, a deep maroon).
- Swap in your own avatars: CAST -> Bunty = <your avatar's name>.
- Voices: each cast line has a "voice ..." setting (boy, girl, deep, high,
  fast, slow). For real voices, record lines (Film tab -> Record Voice), save
  them in an audio/ folder here and add [audio: audio/bunty_01.wav] to a line.
- The music cues are cut to fit their scenes. If you change the dialogue a lot,
  re-make them with tools/make_classroom_audio.py (the lengths are at the bottom).
