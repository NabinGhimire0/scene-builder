"""Original music and comedy sound effects for "The Last Momo", synthesised from
scratch (no samples). Usage:
  python make_momo_audio.py <film folder> [sneaky_seconds dance_seconds finale_seconds]
Music is written to music/*.ogg (via ffmpeg), effects to sfx/*.wav.
"""
import os
import subprocess
import sys

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

RATE = 44100
RNG = np.random.default_rng(7)


def t_axis(seconds):
    return np.arange(int(seconds * RATE)) / RATE


def env(n, attack=0.005, release=0.1, hold=None):
    """Attack / sustain / release envelope over n samples."""
    e = np.ones(n)
    a = max(1, int(attack * RATE))
    r = max(1, int(release * RATE))
    e[:a] = np.linspace(0, 1, a)
    if r < n:
        e[-r:] *= np.linspace(1, 0, r)
    return e


def lowpass(x, freq, order=2):
    return sosfilt(butter(order, freq, "low", fs=RATE, output="sos"), x)


def highpass(x, freq, order=2):
    return sosfilt(butter(order, freq, "high", fs=RATE, output="sos"), x)


def bandpass(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], "band", fs=RATE, output="sos"), x)


def saw(freq, t, harmonics=12):
    out = np.zeros_like(t)
    for k in range(1, harmonics + 1):
        out += np.sin(2 * np.pi * freq * k * t) / k
    return out * 0.6


def square(freq, t, harmonics=9):
    out = np.zeros_like(t)
    for k in range(1, harmonics + 1, 2):
        out += np.sin(2 * np.pi * freq * k * t) / k
    return out * 0.8


def note_hz(name):
    names = {"C": -9, "C#": -8, "D": -7, "D#": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "A": 0, "A#": 1, "B": 2}
    pitch, octave = name[:-1], int(name[-1])
    return 440.0 * 2 ** ((names[pitch] + (octave - 4) * 12) / 12)


def reverb(x, amount=0.25):
    out = x.copy()
    for delay, gain in [(0.029, 0.5), (0.037, 0.45), (0.041, 0.4), (0.053, 0.35)]:
        d = int(delay * RATE)
        y = np.zeros_like(x)
        y[d:] = x[:-d]
        for _ in range(4):
            y[d:] += y[:-d] * gain * 0.5
        out += y * amount * gain
    return out


def place(track, sound, at):
    i = int(at * RATE)
    end = min(len(track), i + len(sound))
    if i < len(track):
        track[i:end] += sound[: end - i]


def normalise(x, peak=0.85):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak


def write_wav(path, x, rate=RATE):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    wavfile.write(path, rate, (normalise(x) * 32767).astype(np.int16))


def write_ogg(path, x):
    tmp = path[:-4] + ".tmp.wav"
    write_wav(tmp, x)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libvorbis", "-q:a", "5", path], check=True)
    os.remove(tmp)


# --- Instruments -------------------------------------------------------------------

def pluck(freq, seconds=0.35, bright=3000):
    t = t_axis(seconds)
    x = saw(freq, t, 10) * np.exp(-t * 9)
    return lowpass(x, bright) * env(len(t), 0.002, 0.05)


def bass(freq, seconds):
    t = t_axis(seconds)
    x = (np.sin(2 * np.pi * freq * t) + 0.4 * saw(freq, t, 6)) * np.exp(-t * 2.5)
    return lowpass(x, 900) * env(len(t), 0.004, 0.06)


def kick():
    t = t_axis(0.35)
    f = 50 + 120 * np.exp(-t * 30)
    return np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 9)


def snare():
    t = t_axis(0.22)
    noise = highpass(RNG.standard_normal(len(t)), 1500) * np.exp(-t * 18)
    tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t * 25)
    return noise * 0.6 + tone * 0.5


def hat(open_hat=False):
    t = t_axis(0.18 if open_hat else 0.05)
    return highpass(RNG.standard_normal(len(t)), 7000) * np.exp(-t * (14 if open_hat else 70)) * 0.35


def madal(low=True):
    """A Nepali madal-style hand drum stroke."""
    t = t_axis(0.3)
    f = (95 if low else 260) * (1 + 0.4 * np.exp(-t * 40))
    x = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * (8 if low else 16))
    return x + highpass(RNG.standard_normal(len(t)), 2000) * np.exp(-t * 60) * 0.2


def brass(freq, seconds):
    t = t_axis(seconds)
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t) * np.clip(t * 3, 0, 1)
    x = saw(freq, t * vib, 14)
    return lowpass(x, 2200) * env(len(t), 0.03, 0.12)


def flute(freq, seconds):
    t = t_axis(seconds)
    vib = np.sin(2 * np.pi * freq * t + 0.6 * np.sin(2 * np.pi * 5 * t) * np.clip(t * 2, 0, 1))
    breath = bandpass(RNG.standard_normal(len(t)), freq, freq * 3) * 0.05
    return (vib + 0.2 * np.sin(4 * np.pi * freq * t) + breath) * env(len(t), 0.04, 0.08)


# --- Music -------------------------------------------------------------------------

def sneaky(seconds):
    """Tiptoe pizzicato in D minor, 104 bpm: the 'up to something' theme."""
    beat = 60 / 104
    track = np.zeros(int((seconds + 1) * RATE))
    walk = ["D3", "F3", "A3", "G#3", "G3", "F3", "E3", "C#3"]
    tune = ["D5", None, "F5", "E5", None, "D5", "C#5", None, "D5", None, "A4", None, "A#4", "A4", "G4", "F4"]
    bar = 0
    t = 0.0
    while t < seconds - beat:
        for i, n in enumerate(walk):
            at = t + i * beat
            if at >= seconds - beat:
                break
            place(track, pluck(note_hz(n), 0.4, 1600) * 0.9, at)
            if i % 2 == 1:
                place(track, hat() * 0.2, at)
        if bar % 2 == 1:
            for i, n in enumerate(tune):
                at = t + i * beat * 0.5
                if n and at < seconds - beat:
                    place(track, pluck(note_hz(n), 0.25, 4500) * 0.45, at)
        t += len(walk) * beat
        bar += 1
    track = lowpass(reverb(track, 0.2), 8000)
    fade = int(0.08 * RATE)  # stops dead: the record scratch cuts it off
    track[int(seconds * RATE) - fade:int(seconds * RATE)] *= np.linspace(1, 0, fade)
    return track[: int(seconds * RATE)]


def dance(seconds):
    """Disco-funk for the dance-off, 118 bpm in E minor."""
    beat = 60 / 118
    track = np.zeros(int((seconds + 1) * RATE))
    bassline = ["E2", "E2", "E3", "E2", "G2", "A2", "B2", "D3"]
    stabs = [["E4", "G4", "B4"], ["D4", "F#4", "A4"], ["C4", "E4", "G4"], ["D4", "F#4", "A4"]]
    t = 0.0
    bar = 0
    while t < seconds:
        for b in range(4):
            at = t + b * beat
            place(track, kick() * 0.9, at)
            if b % 2 == 1:
                place(track, snare() * 0.6, at)
            place(track, hat() * 0.18, at + beat * 0.5)
            place(track, hat(True) * 0.08, at + beat * 0.5)
        for i, n in enumerate(bassline):
            place(track, bass(note_hz(n), beat * 0.45) * 0.7, t + i * beat * 0.5)
        chord = stabs[bar % 4]
        for at in [beat * 1.5, beat * 3.5]:
            stab = sum(brass(note_hz(n), 0.18) for n in chord) * 0.25
            place(track, stab, t + at)
        t += 4 * beat
        bar += 1
    fade = int(1.5 * RATE)
    track[int(seconds * RATE) - fade:int(seconds * RATE)] *= np.linspace(1, 0, fade)
    return lowpass(reverb(track[: int(seconds * RATE)], 0.12), 9000)


def finale(seconds):
    """Happy folk tune with madal drum and flute, 128 bpm in G major, ending on a big chord."""
    beat = 60 / 128
    track = np.zeros(int((seconds + 3) * RATE))
    melody = [("G5", 1), ("A5", 0.5), ("B5", 0.5), ("D6", 1), ("B5", 1), ("A5", 0.5), ("G5", 0.5), ("E5", 1), ("D5", 1), (None, 1),
              ("E5", 0.5), ("G5", 0.5), ("A5", 1), ("B5", 0.5), ("A5", 0.5), ("G5", 1), ("E5", 1), ("G5", 2), (None, 1)]
    chords = [("G2", "D3"), ("C3", "G3"), ("D3", "A3"), ("G2", "D3")]
    t = 0.0
    bar = 0
    while t < seconds - 2:
        root, fifth = chords[bar % 4]
        for b in range(4):
            at = t + b * beat
            place(track, bass(note_hz(root if b % 2 == 0 else fifth), beat * 0.8) * 0.6, at)
            place(track, madal(b % 2 == 0) * 0.5, at)
            place(track, madal(False) * 0.3, at + beat * 0.5)
            if b % 2 == 1:
                place(track, pluck(note_hz(fifth) * 2, 0.2, 3000) * 0.3, at)
        t += 4 * beat
        bar += 1
    t = beat * 4
    while t < seconds - 4:
        for n, length in melody:
            if t >= seconds - 4:
                break
            if n:
                place(track, flute(note_hz(n), length * beat * 0.95) * 0.32, t)
            t += length * beat
    end = seconds - 2.5
    for n in ["G3", "B3", "D4", "G4", "B4"]:
        place(track, brass(note_hz(n), 2.4) * 0.22, end)
    place(track, kick(), end)
    track = lowpass(reverb(track, 0.18), 9000)
    return track[: int(seconds * RATE)]


# --- Sound effects --------------------------------------------------------------------

def snore():
    t = t_axis(2.6)
    inhale = (t < 1.3).astype(float) * np.sin(np.pi * np.clip(t / 1.3, 0, 1))
    exhale = (t >= 1.3).astype(float) * np.sin(np.pi * np.clip((t - 1.3) / 1.3, 0, 1))
    rattle = (1 + 0.8 * np.sin(2 * np.pi * 32 * t)) * lowpass(RNG.standard_normal(len(t)), 500)
    whistle = np.sin(2 * np.pi * (900 + 300 * (t - 1.3)) * t) * 0.15
    return rattle * inhale + whistle * exhale


def choir():
    t = t_axis(3.2)
    out = np.zeros_like(t)
    for n in ["C4", "E4", "G4", "C5", "E5", "G5"]:
        f = note_hz(n)
        out += saw(f * (1 + 0.003 * np.sin(2 * np.pi * 5.2 * t + f)), t, 16)
    voiced = bandpass(out, 600, 900) + bandpass(out, 1050, 1350) * 0.6 + bandpass(out, 2400, 2800) * 0.2
    swell = np.clip(t / 0.8, 0, 1) * np.clip((3.2 - t) / 0.8, 0, 1)
    return reverb(voiced * swell, 0.5)


def scratch():
    t = t_axis(0.7)
    rate = np.where(t < 0.25, 1 + 6 * t, 2.5 - 3 * (t - 0.25))
    noise = RNG.standard_normal(len(t))
    centre = 800 + 2500 * np.abs(np.sin(2 * np.pi * rate * t))
    out = np.zeros_like(t)
    for i in range(0, len(t), 512):
        c = float(np.mean(centre[i:i + 512]))
        out[i:i + 512] = bandpass(noise[i:i + 512], c * 0.7, min(c * 1.4, 20000))
    return out * env(len(t), 0.003, 0.1)


def dun():
    out = np.zeros(int(3.6 * RATE))
    for at, length in [(0.0, 0.35), (0.45, 0.35), (0.95, 2.4)]:
        hit = sum(brass(note_hz(n), length) for n in ["D3", "F3", "A3", "D4"]) * 0.3
        hit *= 1 + 0.25 * np.sin(2 * np.pi * 6 * t_axis(length)) * (length > 1)
        hit += sum(brass(note_hz(n), length) for n in ["D2"]) * 0.5
        place(out, hit, at)
        place(out, kick() * 0.8, at)
    return reverb(out, 0.35)


def slide_whistle():
    t = t_axis(1.4)
    f = np.where(t < 0.7, 600 + 1400 * (t / 0.7) ** 1.2, 2000 - 1500 * ((t - 0.7) / 0.7))
    return np.sin(2 * np.pi * np.cumsum(f) / RATE) * env(len(t), 0.02, 0.1)


def boing():
    t = t_axis(1.0)
    f = 160 * (1 + 0.6 * np.exp(-t * 3) * np.sin(2 * np.pi * 9 * t)) + 120 * np.exp(-t * 6)
    return (np.sin(2 * np.pi * np.cumsum(f) / RATE) + 0.3 * square(1, t) * 0) * np.exp(-t * 3)


def gulp():
    t = t_axis(0.55)
    f = 420 * np.exp(-t * 6) + 110
    x = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 7)
    click = bandpass(RNG.standard_normal(len(t)), 300, 1200) * np.exp(-t * 90) * 0.08
    return lowpass(x + click, 1500)


def burp():
    t = t_axis(1.1)
    f = 85 + 18 * np.sin(2 * np.pi * 3 * t) + RNG.standard_normal(len(t)).cumsum() / RATE * 40
    buzz = saw(1, t, 1) * 0
    tone = np.zeros_like(t)
    phase = np.cumsum(f) / RATE
    for k in range(1, 18):
        tone += np.sin(2 * np.pi * k * phase) / k
    voiced = bandpass(tone, 300, 700) + bandpass(tone, 900, 1300) * 0.5
    return (voiced + buzz) * env(len(t), 0.03, 0.25) * (1 + 0.5 * np.sin(2 * np.pi * 7 * t))


def main():
    folder = sys.argv[1]
    sneaky_s, dance_s, finale_s = (float(v) for v in sys.argv[2:5]) if len(sys.argv) >= 5 else (90.0, 22.0, 25.0)
    sfx = os.path.join(folder, "sfx")
    music = os.path.join(folder, "music")
    for name, fn in [("snore", snore), ("choir", choir), ("scratch", scratch), ("dun", dun),
                     ("whistle", slide_whistle), ("boing", boing), ("gulp", gulp), ("burp", burp)]:
        write_wav(os.path.join(sfx, name + ".wav"), fn())
    os.makedirs(music, exist_ok=True)
    write_ogg(os.path.join(music, "sneaky.ogg"), sneaky(sneaky_s))
    write_ogg(os.path.join(music, "dance.ogg"), dance(dance_s))
    write_ogg(os.path.join(music, "finale.ogg"), finale(finale_s))
    print("AUDIO OK", sneaky_s, dance_s, finale_s)


main()
