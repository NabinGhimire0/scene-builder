"""Builds the props for "The Last Momo" with Blender and exports them as .glb:
momo.glb (one pleated dumpling), plate.glb, momo_steamer.glb (open bamboo
steamer full of momos). Run:  python make_momo_props.py -- <models folder>
"""
import math
import os
import sys

import bpy
import bmesh

OUT = sys.argv[sys.argv.index("--") + 1]
MOMO_RADIUS = 0.045  # a little bigger than life, so it reads on camera


def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def material(name, color, rough=0.6, metal=0.0, sss=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*color, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    if sss > 0:
        b.inputs["Subsurface Weight"].default_value = sss
    return m


def momo(location, rotation=0.0, mat=None):
    """A dumpling: round bottom, gathered pleats twisting up to a knot."""
    mesh = bpy.data.meshes.new("Momo")
    obj = bpy.data.objects.new("Momo", mesh)
    bpy.context.collection.objects.link(obj)
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=48, v_segments=24, radius=MOMO_RADIUS)
    for v in bm.verts:
        x, y, z = v.co
        h = z / MOMO_RADIUS  # -1 bottom .. 1 top
        if h < -0.35:
            z = -0.35 * MOMO_RADIUS + (z + 0.35 * MOMO_RADIUS) * 0.35  # flat base
        angle = math.atan2(y, x)
        up = max(0.0, h)
        pinch = 1.0 - 0.72 * up ** 1.4  # gather towards the top
        pleat = 1.0 + 0.11 * up * math.sin(angle * 12 + up * 3.0)  # 12 folds, twisting
        twist = up * 0.9
        r = math.hypot(x, y) * pinch * pleat
        a = angle + twist
        v.co = (r * math.cos(a), r * math.sin(a), z * 0.95 + up * up * MOMO_RADIUS * 0.35)
    bm.to_mesh(mesh)
    bm.free()
    for poly in mesh.polygons:
        poly.use_smooth = True
    obj.location = location
    obj.location.z += 0.35 * MOMO_RADIUS * 0.35 + 0.35 * MOMO_RADIUS * 0.65
    obj.rotation_euler = (0, 0, rotation)
    if mat:
        obj.data.materials.append(mat)
    return obj


def join_all(name):
    bpy.ops.object.select_all(action="SELECT")
    objs = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    bpy.context.view_layer.objects.active = objs[0]
    bpy.ops.object.join()
    bpy.context.object.name = name
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)


def export(name):
    path = os.path.join(OUT, name)
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB", export_apply=True)
    print("EXPORTED", path)


def dough():
    return material("Dough", (0.93, 0.88, 0.78), rough=0.55, sss=0.25)


def plate_object():
    porcelain = material("Porcelain", (0.95, 0.95, 0.93), rough=0.12)
    rim = material("Rim", (0.55, 0.12, 0.1), rough=0.3)
    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=0.15, depth=0.012, location=(0, 0, 0.006))
    base = bpy.context.object
    base.data.materials.append(porcelain)
    bpy.ops.mesh.primitive_torus_add(major_radius=0.155, minor_radius=0.008, major_segments=64, minor_segments=8, location=(0, 0, 0.014))
    ring = bpy.context.object
    ring.data.materials.append(rim)
    bpy.ops.object.shade_smooth()


def steamer_object():
    bamboo = material("Bamboo", (0.72, 0.55, 0.3), rough=0.7)
    bamboo_dark = material("BambooDark", (0.48, 0.33, 0.16), rough=0.75)
    leaf = material("Leaf", (0.38, 0.55, 0.22), rough=0.6)
    d = dough()
    # Two stacked tiers: walls are open cylinders made solid.
    for i, z in enumerate([0.0, 0.085]):
        bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=0.19, depth=0.08, location=(0, 0, z + 0.04), end_fill_type="NOTHING")
        wall = bpy.context.object
        mod = wall.modifiers.new("Solid", "SOLIDIFY")
        mod.thickness = 0.012
        bpy.ops.object.modifier_apply(modifier="Solid")
        wall.data.materials.append(bamboo if i == 0 else bamboo_dark)
        bpy.ops.mesh.primitive_torus_add(major_radius=0.192, minor_radius=0.006, location=(0, 0, z + 0.075))
        bpy.context.object.data.materials.append(bamboo_dark)
    # Slatted floor of the top tier, a leaf liner, and momos on it.
    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=0.185, depth=0.006, location=(0, 0, 0.1))
    bpy.context.object.data.materials.append(bamboo)
    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=0.17, depth=0.003, location=(0, 0, 0.105))
    bpy.context.object.data.materials.append(leaf)
    spots = [(0, 0)] + [(0.105 * math.cos(a), 0.105 * math.sin(a)) for a in [i * math.tau / 7 for i in range(7)]]
    for k, (x, y) in enumerate(spots):
        momo((x, y, 0.107), rotation=k * 0.8, mat=d)


def main():
    os.makedirs(OUT, exist_ok=True)
    reset()
    momo((0, 0, 0), mat=dough())
    export("momo.glb")
    reset()
    plate_object()
    join_all("Plate")
    export("plate.glb")
    reset()
    steamer_object()
    join_all("Steamer")
    export("momo_steamer.glb")


main()
