THE LAST MOMO - a 3-minute Scene Builder comedy
================================================

A family, one momo left on the plate, and nobody willing to share.
Hari tries to sneak it, Sita catches him, little Chhotu invents a flying
elephant, a dance-off decides everything... and Tommy the dog has other plans.
Hajurba sleeps through it all. Or does he?

HOW TO WATCH
1. In Scene Builder press Script -> Open... -> choose the_last_momo.zip
   (or "Package folder..." and pick this folder).
2. Press Build Film, then Watch (or Play Cinematic).
3. Export Video -> MP4 to make the video (needs FFmpeg for the music and sounds).

WHAT'S INSIDE
film.script            the screenplay: 6 scenes, 5 characters, ~45 camera shots
models/momo.glb        one pleated momo           (made in Blender)
models/plate.glb       a plate with a red rim     (made in Blender)
models/momo_steamer.glb an open bamboo steamer full of momos (made in Blender)
music/sneaky.ogg       tiptoe pizzicato theme - stops dead at the record scratch
music/dance.ogg        disco-funk for the dance-off
music/finale.ogg       happy folk tune with madal drum and flute
sfx/*.wav              snore, angel choir, record scratch, dun-dun-DUUN,
                       slide whistle, boing, gulp, burp
tools/                 the Blender and audio scripts that made the files above,
                       if you want to change the props or music

All models, music and sounds are original, made for this film; use them freely.

MAKE IT YOURS
- Change names, clothes and colours in the CAST section.
- Swap in your own avatars: CAST -> Hari = <your avatar's name>.
- Add real voices: record lines (Film tab -> Record Voice), save them in an
  audio/ folder here and add [audio: audio/hari_01.wav] to a dialogue line.
- Everything is ordinary scene content after building: move cameras, change
  lights, retime keys, then Save.
