"""Original music and ambience for FOUR SEASONS ON ONE BENCH, synthesised from scratch
(no samples, no recordings). Usage:
    python tools/make_audio.py
Needs numpy, scipy and ffmpeg (for .ogg). Music -> music/*.ogg, ambience -> sfx/*.wav.

One theme - "their tune" (E D C D E E E) - in four seasons: warm piano and strings in
summer, the same tune slower and in a minor key with a cello in autumn, a single
piano line with a music box in winter (her part of the harmony missing), and in spring
the theme again, gently, with the full harmony back at the end.
Cue lengths are at the bottom.
"""
import os
import subprocess

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

RATE = 44100
RNG = np.random.default_rng(4)
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")


# --- Building blocks ---------------------------------------------------------------

def t_axis(seconds):
    return np.arange(int(seconds * RATE)) / RATE


def lowpass(x, f, order=2):
    return sosfilt(butter(order, f, "low", fs=RATE, output="sos"), x)


def highpass(x, f, order=2):
    return sosfilt(butter(order, f, "high", fs=RATE, output="sos"), x)


def hz(name):
    names = {"C": -9, "C#": -8, "D": -7, "D#": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "A": 0, "A#": 1, "B": 2}
    return 440.0 * 2 ** ((names[name[:-1]] + (int(name[-1]) - 4) * 12) / 12)


def place(track, sound, at):
    i = int(at * RATE)
    if i >= len(track):
        return
    end = min(len(track), i + len(sound))
    track[i:end] += sound[: end - i]


def reverb(x, amount=0.3):
    out = x.copy()
    for delay, gain in [(0.031, 0.6), (0.043, 0.5), (0.059, 0.45), (0.083, 0.4), (0.113, 0.35), (0.157, 0.3)]:
        d = int(delay * RATE)
        y = np.zeros_like(x)
        y[d:] = x[:-d]
        for _ in range(5):
            y[d:] += y[:-d] * gain * 0.55
        out += y * amount * gain
    return out


def fade(x, fade_in=0.05, fade_out=2.0):
    n = len(x)
    e = np.ones(n)
    a = int(fade_in * RATE)
    b = int(fade_out * RATE)
    if a:
        e[:a] = np.linspace(0, 1, a)
    if b:
        e[-b:] *= np.linspace(1, 0, b) ** 1.5
    return x * e


def normalise(x, peak=0.85):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak


def piano(freq, seconds=2.5, velocity=1.0):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for k, amp in enumerate([1.0, 0.45, 0.25, 0.12, 0.08, 0.04], start=1):
        f = freq * k * (1 + 0.0004 * k * k)
        out += amp * np.sin(2 * np.pi * f * t) * np.exp(-t * (1.2 + 0.9 * k))
    hammer = np.exp(-t * 60) * RNG.standard_normal(len(t)) * 0.02
    attack = np.minimum(1, t / 0.004)
    return (out + hammer) * attack * velocity


def pad(freqs, seconds, brightness=900, detune=0.003):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for f in freqs:
        for d in (-detune, 0, detune):
            phase = 2 * np.pi * f * (1 + d) * t
            out += sum(np.sin(k * phase) / k for k in range(1, 8))
    out = lowpass(out, brightness, 2)
    swell = np.minimum(1, t / 1.5) * np.minimum(1, (seconds - t) / 1.5)
    return out * swell / (len(freqs) * 3)


def strings(freq, seconds, attack=0.08):
    t = t_axis(seconds)
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t)
    phase = 2 * np.pi * freq * np.cumsum(vib) / RATE
    out = sum(np.sin(k * phase) * (0.7 ** k) for k in range(1, 9))
    env = np.minimum(1, t / attack) * np.minimum(1, (seconds - t) / 0.05)
    return lowpass(out, 2600) * env


def kick(seconds=0.6, depth=1.0):
    t = t_axis(seconds)
    f = 45 + 110 * np.exp(-t * 28)
    body = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 7)
    click = RNG.standard_normal(len(t)) * np.exp(-t * 180) * 0.15
    return (body + click) * depth


def taiko(seconds=1.2):
    t = t_axis(seconds)
    f = 62 + 50 * np.exp(-t * 12)
    body = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 3.2)
    skin = lowpass(RNG.standard_normal(len(t)), 700) * np.exp(-t * 14) * 0.5
    return body + skin


def snare(seconds=0.35):
    t = t_axis(seconds)
    noise = highpass(RNG.standard_normal(len(t)), 1800) * np.exp(-t * 20)
    tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t * 30) * 0.5
    return (noise * 0.6 + tone) * 0.8


def hat(seconds=0.08):
    t = t_axis(seconds)
    return highpass(RNG.standard_normal(len(t)), 7000) * np.exp(-t * 60) * 0.25


def heartbeat():
    beat = np.zeros(int(0.9 * RATE))
    place(beat, kick(0.4, 1.0) * 0.9, 0.0)
    place(beat, kick(0.4, 0.7) * 0.6, 0.22)
    return lowpass(beat, 160)


def to_ogg(name, x):
    os.makedirs(os.path.join(ROOT, "music"), exist_ok=True)
    wav = os.path.join(ROOT, "music", name + ".wav")
    stereo = np.stack([x, np.roll(x, 180)], axis=1)
    wavfile.write(wav, RATE, (normalise(stereo, 0.9) * 32767).astype(np.int16))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "5",
                    os.path.join(ROOT, "music", name + ".ogg")], check=True)
    os.remove(wav)


def to_wav(name, x, peak=0.9):
    os.makedirs(os.path.join(ROOT, "sfx"), exist_ok=True)
    stereo = np.stack([x, np.roll(x, 90)], axis=1)
    wavfile.write(os.path.join(ROOT, "sfx", name + ".wav"), RATE, (normalise(stereo, peak) * 32767).astype(np.int16))




def pluck(freq, seconds=0.6, bright=2500):
    t = t_axis(seconds)
    out = sum(np.sin(2 * np.pi * freq * k * t) * (0.55 ** k) for k in range(1, 6))
    return lowpass(out * np.exp(-t * 7) * np.minimum(1, t / 0.003), bright)


def chord_pad(names, seconds, brightness=900, level=0.5):
    return pad([hz(n) for n in names], seconds, brightness) * level


def music_box(freq, seconds=1.6):
    t = t_axis(seconds)
    out = np.sin(2 * np.pi * freq * t) + 0.35 * np.sin(2 * np.pi * freq * 4.02 * t) * np.exp(-t * 9)
    return out * np.exp(-t * 3.2) * np.minimum(1, t / 0.002)




THEME = ["E5", "D5", "C5", "D5", "E5", "E5", "E5", "D5", "D5", "D5", "E5", "G5", "G5"]
DUR = [1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2]           # in beats


def cello(freq, seconds, attack=0.25):
    t = t_axis(seconds)
    vib = 1 + 0.005 * np.sin(2 * np.pi * 5.0 * t) * np.minimum(1, t / 0.6)
    phase = 2 * np.pi * freq * np.cumsum(vib) / RATE
    out = sum(np.sin(k * phase) * (0.62 ** k) for k in range(1, 10))
    env = np.minimum(1, t / attack) * np.minimum(1, (seconds - t) / 0.4)
    return lowpass(out, 1800) * env


def theme(out, start, beat, transpose=1.0, level=0.5, minor=False, instrument="piano", repeats=1):
    at = start
    for r in range(repeats):
        for n, d in zip(THEME, DUR):
            name = n
            if minor and name.startswith("E"):
                name = "D#" + name[1:]   # a flattened third
            f = hz(name) * transpose
            if instrument == "box":
                place(out, music_box(f, 2.0) * level, at)
            elif instrument == "cello":
                place(out, cello(f / 2, d * beat + 0.3) * level * 0.25, at)
            else:
                place(out, piano(f, max(2.0, d * beat + 1.0), level), at)
            at += d * beat
        at += beat * 2
    return at


def chords(out, start, end, progression, bar, level=0.4, strings_level=0.0, octave=1.0):
    at, k = start, 0
    while at < end - 0.5:
        ch = progression[k % len(progression)]
        for i, n in enumerate(ch):
            place(out, piano(hz(n) * octave, bar + 0.5, level), at + i * 0.09)
            if strings_level > 0:
                place(out, strings(hz(n) * octave, bar + 0.4, 0.8) * strings_level, at)
        at += bar
        k += 1


C_MAJOR = [["C3", "G3", "E4"], ["A2", "E3", "C4"], ["F2", "C3", "A3"], ["G2", "D3", "B3"]]
A_MINOR = [["A2", "E3", "C4"], ["F2", "C3", "A3"], ["D3", "A3", "F4"], ["E2", "B2", "G#3"]]


# --- Cues ---------------------------------------------------------------------------

def summer(seconds):
    """Warm C major: piano chords, the theme on top, strings growing in."""
    out = np.zeros(int((seconds + 6) * RATE))
    chords(out, 0.0, seconds - 2, C_MAJOR, 3.2, 0.35, 0.03)
    theme(out, 6.4, 0.8, level=0.5, repeats=2)
    return fade(reverb(out[: int(seconds * RATE)], 0.45), 1.5, 4.0)


def autumn(seconds):
    """The same tune, slower, in A minor, with a cello; falling-leaf piano notes."""
    out = np.zeros(int((seconds + 6) * RATE))
    chords(out, 0.0, seconds - 2, A_MINOR, 3.6, 0.32, 0.025)
    theme(out, 3.6, 1.0, transpose=0.5, level=0.9, minor=True, instrument="cello")
    theme(out, 25.0, 1.0, level=0.38, minor=True)
    for i in range(14):
        place(out, piano(hz(["E6", "C6", "A5", "B5"][i % 4]), 2.0, 0.12), 2.0 + i * 2.9 + RNG.uniform(0, 0.6))
    return fade(reverb(out[: int(seconds * RATE)], 0.5), 1.5, 4.0)


def winter(seconds):
    """Alone: one piano line, a high music box, no harmony underneath; then one low chord."""
    out = np.zeros(int((seconds + 6) * RATE))
    t = t_axis(seconds)
    out[: len(t)] += lowpass(np.sin(2 * np.pi * hz("A1") * t), 200) * 0.08 * np.minimum(1, t / 4)
    theme(out, 4.0, 1.25, level=0.42, minor=True)
    theme(out, 7.5, 1.25, transpose=2.0, level=0.12, minor=True, instrument="box")
    for i, n in enumerate(["A2", "E3", "C4"]):
        place(out, piano(hz(n), 8.0, 0.35), seconds - 14.0 + i * 0.4)
    return fade(reverb(out[: int(seconds * RATE)], 0.6), 1.5, 5.0)


def spring(seconds, warm_at, chord_at):
    """Gentle: the music box and piano play the tune again; when Harold says "Sit.
    There's room." the harmony comes back, and a full chord ends the film."""
    out = np.zeros(int((seconds + 8) * RATE))
    theme(out, 1.0, 0.9, level=0.18, instrument="box")
    chords(out, 0.0, warm_at, [["C3", "G3"], ["A2", "E3"]], 4.0, 0.25)
    chords(out, warm_at, chord_at, C_MAJOR, 3.0, 0.38, 0.04)
    theme(out, warm_at + 1.5, 0.8, level=0.5)
    for i, n in enumerate(["C3", "G3", "C4", "E4", "G4", "C5"]):
        place(out, piano(hz(n), 8.0, 0.5), chord_at + i * 0.07)
        place(out, strings(hz(n), seconds - chord_at + 1, 1.2) * 0.05, chord_at)
    place(out, music_box(hz("E6"), 3.0) * 0.25, chord_at + 1.0)
    return fade(reverb(out[: int(seconds * RATE)], 0.5), 1.0, 5.0)


# --- Ambience ---------------------------------------------------------------------

def birds(seconds=40.0):
    """Evening birds by a lake: sparse chirps and trills, with a soft breeze."""
    out = np.zeros(int(seconds * RATE))
    t = t_axis(seconds)
    out += lowpass(RNG.standard_normal(len(t)), 400) * 0.05
    at = 0.5
    while at < seconds - 1.0:
        kind = RNG.integers(0, 3)
        base = RNG.uniform(2600, 4200)
        n = RNG.integers(2, 6)
        for k in range(n):
            d = RNG.uniform(0.05, 0.12)
            tt = t_axis(d)
            sweep = base * (1 + (0.25 if kind == 0 else -0.2) * tt / d)
            chirp = np.sin(2 * np.pi * np.cumsum(sweep) / RATE) * np.sin(np.pi * tt / d) ** 2
            place(out, chirp * RNG.uniform(0.15, 0.35), at + k * (d + 0.03))
        at += RNG.uniform(0.8, 3.0)
    return fade(out, 1.0, 2.0)


def wind(seconds=40.0, low=300, level=1.0):
    t = t_axis(seconds)
    noise = RNG.standard_normal(len(t))
    gust = 0.55 + 0.45 * np.sin(2 * np.pi * 0.11 * t) * np.sin(2 * np.pi * 0.047 * t + 1.0)
    out = lowpass(noise, low) * gust + lowpass(highpass(noise, 600), 1600) * gust * 0.15
    return fade(out * level, 2.0, 3.0)


def to_ambience(name, x, peak):
    os.makedirs(os.path.join(ROOT, "sfx"), exist_ok=True)
    stereo = np.stack([x, np.roll(x, 900)], axis=1)
    wavfile.write(os.path.join(ROOT, "sfx", name + ".wav"), RATE, (normalise(stereo, peak) * 32767).astype(np.int16))


if __name__ == "__main__":
    # Cue lengths fit the scene windows of film.script (start -> next cue).
    to_ogg("summer", summer(44.0))               # 0.0   -> 43.5
    to_ogg("autumn", autumn(44.3))               # 43.5  -> 87.3
    to_ogg("winter", winter(38.3))               # 87.3  -> 125.1
    to_ogg("spring", spring(55.5, 22.6, 46.0))   # 125.1 -> end: warm on "Sit. There's room." (~147.7), chord on the last line (~171)
    to_ambience("birds", birds(46.0), 0.5)
    to_ambience("wind", wind(46.0, 300), 0.6)
    to_ambience("winter_wind", wind(40.0, 220), 0.6)
    print("made music/*.ogg and sfx/*.wav")
