FOUR SEASONS ON ONE BENCH  (about 3 min)
An original Scene Builder short in realistic 3D. Almost no words: the seasons tell it.

Harold and Margaret have watched the sunset from the same lakeside bench for forty-one
years. Summer. Autumn - "Keep coming here. Even when it's cold." Then winter, when
Harold comes alone, sits on his side and leaves hers empty. In spring a young couple
can't find anywhere to sit. "Sit. There's room."

HOW TO WATCH
  Needs Scene Builder 1.11 or newer (new characters, clothes, autumn colours, the
  lake fix). Script -> Open... -> four_seasons.zip -> Build Film -> Watch.
  For the best look, set Render quality to High or Cinematic and export the video.

CHAPTERS
    0:00  Summer   golden evening; "Same bench?" - "Same bench. Forty-one years."
    0:43  Autumn   gold trees, falling leaves; "Promise me something... Keep coming here."
    1:27  Winter   snow; Harold alone. "It's cold, Maggie. I came anyway."
    2:05  Spring   morning; a young couple; "Every evening. For forty-two years."
    2:51  End      "Love is a place you keep coming back to."

CAST (each season is its own actor, dressed for it)
  Harold / HaroldAutumn / HaroldWinter / HaroldSpring - glasses; sweater in autumn,
           coat, scarf and beanie in winter
  Margaret / MargaretAutumn - grey hair in a bun; a scarf in autumn
  Leo and Ana - the young couple in spring

MUSIC
  One theme, "their tune", in four seasons: warm piano in summer, slow and minor with a
  cello in autumn, a single line with no harmony in winter (her part is missing), and
  whole again in spring. Ambience: evening birds, autumn wind, winter wind.

FILES
  film.script            the film (Lakeside Campfire, CAMERA: manual)
  music/*.ogg            summer, autumn, winter, spring (tools/make_audio.py)
  sfx/*.wav              birds, wind, winter_wind (tools/make_audio.py)
  storyboard.png         frames from a test build

Every note and sound was made from scratch by the tool. Story and lines are original.
