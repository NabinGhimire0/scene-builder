Night Walk - an example Scene Builder film package.

film.json                 the script (JSON form; the text form works the same way)
models/paper_lantern.glb  a glowing paper lantern made in Blender

Open it with Script -> Open... -> choose night_walk.zip, then Build Film.
Add voices: put .wav files in an audio/ folder and add [audio: file.wav] to a line.
