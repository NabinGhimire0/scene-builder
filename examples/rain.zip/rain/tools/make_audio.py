"""Original music and sound for RAIN, synthesised from scratch (no samples, no
recordings). Usage:
    python tools/make_audio.py
Needs numpy, scipy and ffmpeg (for .ogg). Music -> music/*.ogg, sound -> sfx/*.wav.

The score is built on one small piano figure, like raindrops (A C E D C): alone and
hesitant for the strangers, warm with strings once they are friends, gone thin and
cold on the empty nights - only the raindrop figure, with a cello - then rising when
she finds the note, and warm in C major at the end, when the rain has stopped.
Cue lengths are at the bottom.
"""
import os
import subprocess

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

RATE = 44100
RNG = np.random.default_rng(940)
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")


# --- Building blocks ---------------------------------------------------------------

def t_axis(seconds):
    return np.arange(int(seconds * RATE)) / RATE


def lowpass(x, f, order=2):
    return sosfilt(butter(order, f, "low", fs=RATE, output="sos"), x)


def highpass(x, f, order=2):
    return sosfilt(butter(order, f, "high", fs=RATE, output="sos"), x)


def hz(name):
    names = {"C": -9, "C#": -8, "D": -7, "D#": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "A": 0, "A#": 1, "B": 2}
    return 440.0 * 2 ** ((names[name[:-1]] + (int(name[-1]) - 4) * 12) / 12)


def place(track, sound, at):
    i = int(at * RATE)
    if i >= len(track):
        return
    end = min(len(track), i + len(sound))
    track[i:end] += sound[: end - i]


def reverb(x, amount=0.3):
    out = x.copy()
    for delay, gain in [(0.031, 0.6), (0.043, 0.5), (0.059, 0.45), (0.083, 0.4), (0.113, 0.35), (0.157, 0.3)]:
        d = int(delay * RATE)
        y = np.zeros_like(x)
        y[d:] = x[:-d]
        for _ in range(5):
            y[d:] += y[:-d] * gain * 0.55
        out += y * amount * gain
    return out


def fade(x, fade_in=0.05, fade_out=2.0):
    n = len(x)
    e = np.ones(n)
    a = int(fade_in * RATE)
    b = int(fade_out * RATE)
    if a:
        e[:a] = np.linspace(0, 1, a)
    if b:
        e[-b:] *= np.linspace(1, 0, b) ** 1.5
    return x * e


def normalise(x, peak=0.85):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak


def piano(freq, seconds=2.5, velocity=1.0):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for k, amp in enumerate([1.0, 0.45, 0.25, 0.12, 0.08, 0.04], start=1):
        f = freq * k * (1 + 0.0004 * k * k)
        out += amp * np.sin(2 * np.pi * f * t) * np.exp(-t * (1.2 + 0.9 * k))
    hammer = np.exp(-t * 60) * RNG.standard_normal(len(t)) * 0.02
    attack = np.minimum(1, t / 0.004)
    return (out + hammer) * attack * velocity


def pad(freqs, seconds, brightness=900, detune=0.003):
    t = t_axis(seconds)
    out = np.zeros_like(t)
    for f in freqs:
        for d in (-detune, 0, detune):
            phase = 2 * np.pi * f * (1 + d) * t
            out += sum(np.sin(k * phase) / k for k in range(1, 8))
    out = lowpass(out, brightness, 2)
    swell = np.minimum(1, t / 1.5) * np.minimum(1, (seconds - t) / 1.5)
    return out * swell / (len(freqs) * 3)


def strings(freq, seconds, attack=0.08):
    t = t_axis(seconds)
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t)
    phase = 2 * np.pi * freq * np.cumsum(vib) / RATE
    out = sum(np.sin(k * phase) * (0.7 ** k) for k in range(1, 9))
    env = np.minimum(1, t / attack) * np.minimum(1, (seconds - t) / 0.05)
    return lowpass(out, 2600) * env


def kick(seconds=0.6, depth=1.0):
    t = t_axis(seconds)
    f = 45 + 110 * np.exp(-t * 28)
    body = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 7)
    click = RNG.standard_normal(len(t)) * np.exp(-t * 180) * 0.15
    return (body + click) * depth


def taiko(seconds=1.2):
    t = t_axis(seconds)
    f = 62 + 50 * np.exp(-t * 12)
    body = np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-t * 3.2)
    skin = lowpass(RNG.standard_normal(len(t)), 700) * np.exp(-t * 14) * 0.5
    return body + skin


def snare(seconds=0.35):
    t = t_axis(seconds)
    noise = highpass(RNG.standard_normal(len(t)), 1800) * np.exp(-t * 20)
    tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t * 30) * 0.5
    return (noise * 0.6 + tone) * 0.8


def hat(seconds=0.08):
    t = t_axis(seconds)
    return highpass(RNG.standard_normal(len(t)), 7000) * np.exp(-t * 60) * 0.25


def heartbeat():
    beat = np.zeros(int(0.9 * RATE))
    place(beat, kick(0.4, 1.0) * 0.9, 0.0)
    place(beat, kick(0.4, 0.7) * 0.6, 0.22)
    return lowpass(beat, 160)


def to_ogg(name, x):
    os.makedirs(os.path.join(ROOT, "music"), exist_ok=True)
    wav = os.path.join(ROOT, "music", name + ".wav")
    stereo = np.stack([x, np.roll(x, 180)], axis=1)
    wavfile.write(wav, RATE, (normalise(stereo, 0.9) * 32767).astype(np.int16))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "5",
                    os.path.join(ROOT, "music", name + ".ogg")], check=True)
    os.remove(wav)


def to_wav(name, x, peak=0.9):
    os.makedirs(os.path.join(ROOT, "sfx"), exist_ok=True)
    stereo = np.stack([x, np.roll(x, 90)], axis=1)
    wavfile.write(os.path.join(ROOT, "sfx", name + ".wav"), RATE, (normalise(stereo, peak) * 32767).astype(np.int16))




def pluck(freq, seconds=0.6, bright=2500):
    t = t_axis(seconds)
    out = sum(np.sin(2 * np.pi * freq * k * t) * (0.55 ** k) for k in range(1, 6))
    return lowpass(out * np.exp(-t * 7) * np.minimum(1, t / 0.003), bright)


def chord_pad(names, seconds, brightness=900, level=0.5):
    return pad([hz(n) for n in names], seconds, brightness) * level


def music_box(freq, seconds=1.6):
    t = t_axis(seconds)
    out = np.sin(2 * np.pi * freq * t) + 0.35 * np.sin(2 * np.pi * freq * 4.02 * t) * np.exp(-t * 9)
    return out * np.exp(-t * 3.2) * np.minimum(1, t / 0.002)




def cello(freq, seconds, attack=0.25):
    t = t_axis(seconds)
    vib = 1 + 0.005 * np.sin(2 * np.pi * 5.0 * t) * np.minimum(1, t / 0.6)
    phase = 2 * np.pi * freq * np.cumsum(vib) / RATE
    out = sum(np.sin(k * phase) * (0.62 ** k) for k in range(1, 10))
    env = np.minimum(1, t / attack) * np.minimum(1, (seconds - t) / 0.4)
    return lowpass(out, 1800) * env


def theme(out, start, beat, transpose=1.0, level=0.5, minor=False, instrument="piano", repeats=1):
    at = start
    for r in range(repeats):
        for n, d in zip(THEME, DUR):
            name = n
            if minor and name.startswith("E"):
                name = "D#" + name[1:]   # a flattened third
            f = hz(name) * transpose
            if instrument == "box":
                place(out, music_box(f, 2.0) * level, at)
            elif instrument == "cello":
                place(out, cello(f / 2, d * beat + 0.3) * level * 0.25, at)
            else:
                place(out, piano(f, max(2.0, d * beat + 1.0), level), at)
            at += d * beat
        at += beat * 2
    return at


def chords(out, start, end, progression, bar, level=0.4, strings_level=0.0, octave=1.0):
    at, k = start, 0
    while at < end - 0.5:
        ch = progression[k % len(progression)]
        for i, n in enumerate(ch):
            place(out, piano(hz(n) * octave, bar + 0.5, level), at + i * 0.09)
            if strings_level > 0:
                place(out, strings(hz(n) * octave, bar + 0.4, 0.8) * strings_level, at)
        at += bar
        k += 1


THEME = ["A4", "C5", "E5", "D5", "C5"]
DUR = [1, 1, 1, 1, 2]


def theme(out, start, beat, transpose=1.0, level=0.5, instrument="piano", repeats=1, gap=2):
    at = start
    for r in range(repeats):
        for n, d in zip(THEME, DUR):
            f = hz(n) * transpose
            if instrument == "box":
                place(out, music_box(f, 2.0) * level, at)
            elif instrument == "cello":
                place(out, cello(f / 2, d * beat + 0.4) * level * 0.25, at)
            else:
                place(out, piano(f, max(2.0, d * beat + 1.2), level), at)
            at += d * beat
        at += beat * gap
    return at


def chords(out, start, end, progression, bar, level=0.35, strings_level=0.0):
    at, k = start, 0
    while at < end - 0.5:
        ch = progression[k % len(progression)]
        for i, n in enumerate(ch):
            place(out, piano(hz(n), bar + 0.6, level), at + i * 0.1)
            if strings_level > 0:
                place(out, strings(hz(n), bar + 0.4, 0.9) * strings_level, at)
        at += bar
        k += 1


A_MINOR = [["A2", "E3", "C4"], ["F2", "C3", "A3"], ["C3", "G3", "E4"], ["G2", "D3", "B3"]]
C_MAJOR = [["C3", "G3", "E4"], ["A2", "E3", "C4"], ["F2", "C3", "A3"], ["G2", "D3", "B3"]]


# --- Cues ---------------------------------------------------------------------------

def opening(seconds):
    """The raindrop figure alone, slow, with a low pad; one chord on the title."""
    out = np.zeros(int((seconds + 6) * RATE))
    place(out, chord_pad(["A2", "E3"], seconds, 500, 0.35), 0)
    theme(out, 1.0, 0.9, level=0.42)
    for i, n in enumerate(["A2", "E3", "C4", "E4"]):
        place(out, piano(hz(n), 6.0, 0.45), 9.0 + i * 0.08)
    return fade(reverb(out[: int(seconds * RATE)], 0.55), 0.8, 2.5)


def strangers(seconds):
    """Hesitant: the figure on piano with long silences and soft A minor chords."""
    out = np.zeros(int((seconds + 6) * RATE))
    chords(out, 0.0, seconds - 2, A_MINOR, 4.8, 0.25)
    at = 2.0
    while at < seconds - 6:
        at = theme(out, at, 0.95, level=0.38, gap=6)
    return fade(reverb(out[: int(seconds * RATE)], 0.5), 1.0, 3.0)


def friends(seconds):
    """Warm: C major, the figure turned major (C E G F E), strings growing."""
    out = np.zeros(int((seconds + 6) * RATE))
    chords(out, 0.0, seconds - 2, C_MAJOR, 3.4, 0.33, 0.03)
    at = 1.7
    while at < seconds - 5:
        at = theme(out, at, 0.85, transpose=hz("C5") / hz("A4"), level=0.42, gap=3)
    for k in range(int(seconds / 6.8)):
        place(out, music_box(hz(["E6", "G6", "C6", "D6"][k % 4]), 2.0) * 0.12, 3.0 + k * 6.8)
    return fade(reverb(out[: int(seconds * RATE)], 0.45), 1.0, 3.0)


def empty(seconds, note_at):
    """The empty nights: no chords, only the figure, slower each time, with a cello.
    When she finds the note, the strings rise and the pulse quickens."""
    out = np.zeros(int((seconds + 6) * RATE))
    t = t_axis(seconds)
    out[: len(t)] += lowpass(np.sin(2 * np.pi * hz("A1") * t), 180) * 0.08 * np.minimum(1, t / 5)
    at, k = 2.0, 0
    while at < note_at - 6:
        at = theme(out, at, 1.1 + 0.15 * k, level=0.36, gap=4)
        k += 1
    theme(out, 6.0, 1.4, level=0.9, instrument="cello")
    for i, ch in enumerate([["F2", "C3", "A3"], ["G2", "D3", "B3"], ["A2", "E3", "C4", "E4"]]):
        for n in ch:
            place(out, strings(hz(n), 3.4, 1.0) * 0.06, note_at + i * 3.0)
            place(out, piano(hz(n), 3.5, 0.45), note_at + i * 3.0)
    beat = 0.36
    b = 0
    while note_at + 9.0 + b * beat < seconds - 1:
        place(out, piano(hz(["A3", "E4", "C4", "E4"][b % 4]), 0.9, 0.35), note_at + 9.0 + b * beat)
        if b % 4 == 0:
            place(out, taiko() * 0.3, note_at + 9.0 + b * beat)
        b += 1
    return fade(reverb(out[: int(seconds * RATE)], 0.5), 1.0, 1.5)


def home(seconds, chord_at):
    """The rain has stopped: the figure in C major, piano and music box, a held chord."""
    out = np.zeros(int((seconds + 8) * RATE))
    chords(out, 0.0, chord_at, C_MAJOR, 3.2, 0.36, 0.04)
    at = 1.6
    while at < chord_at - 4:
        at = theme(out, at, 0.8, transpose=hz("C5") / hz("A4"), level=0.45, gap=3)
    theme(out, 4.8, 0.8, transpose=2 * hz("C5") / hz("A4"), level=0.12, instrument="box")
    for i, n in enumerate(["C3", "G3", "C4", "E4", "G4", "C5"]):
        place(out, piano(hz(n), 8.0, 0.5), chord_at + i * 0.07)
        place(out, strings(hz(n), seconds - chord_at + 1, 1.2) * 0.05, chord_at)
    place(out, music_box(hz("E6"), 3.0) * 0.25, chord_at + 1.2)
    return fade(reverb(out[: int(seconds * RATE)], 0.5), 0.8, 5.0)


# --- Sound ------------------------------------------------------------------------

def rain(seconds):
    """Steady rain: a soft hiss, drops on the shelter roof, and a low rumble of the city."""
    t = t_axis(seconds)
    noise = RNG.standard_normal(len(t))
    hiss = lowpass(highpass(noise, 900), 7000) * 0.35
    body = lowpass(noise, 600) * 0.25
    out = hiss + body
    n_drops = int(seconds * 14)
    for k in range(n_drops):
        d = t_axis(0.03)
        drop = np.sin(2 * np.pi * RNG.uniform(1200, 3200) * d) * np.exp(-d * 180) * RNG.uniform(0.05, 0.25)
        place(out, drop, RNG.uniform(0, seconds - 0.05))
    out += lowpass(RNG.standard_normal(len(t)), 90) * 0.4
    return fade(out, 2.0, 4.0)


def drips(seconds):
    """After the rain: slow drips from the roof and gutters."""
    out = np.zeros(int(seconds * RATE))
    t = t_axis(seconds)
    out += lowpass(RNG.standard_normal(len(t)), 300) * 0.04
    at = 0.3
    while at < seconds - 0.2:
        d = t_axis(0.12)
        f = RNG.uniform(900, 1700) * (1 + 0.6 * d / 0.12)
        place(out, np.sin(2 * np.pi * np.cumsum(f) / RATE) * np.exp(-d * 40) * RNG.uniform(0.2, 0.5), at)
        at += RNG.uniform(0.3, 1.4)
    return fade(out, 1.5, 3.0)


def bus():
    """A city bus: engine rising, air brakes, the door, engine leaving."""
    seconds = 9.0
    t = t_axis(seconds)
    env = np.interp(t, [0, 3.5, 4.5, 6.5, 9.0], [0.1, 1.0, 0.6, 0.6, 0.0])
    f = 38 + 14 * env
    engine = lowpass(np.sign(np.sin(2 * np.pi * np.cumsum(f) / RATE)) * 0.5 + RNG.standard_normal(len(t)) * 0.3, 220) * env * 1.6
    out = engine
    hiss_t = t_axis(1.0)
    place(out, highpass(RNG.standard_normal(len(hiss_t)), 2000) * np.exp(-hiss_t * 3) * 0.35, 4.2)
    door_t = t_axis(0.8)
    place(out, lowpass(RNG.standard_normal(len(door_t)), 600) * np.sin(np.pi * door_t / 0.8) * 0.3, 5.0)
    return out


def to_ambience(name, x, peak):
    os.makedirs(os.path.join(ROOT, "sfx"), exist_ok=True)
    stereo = np.stack([x, np.roll(x, 700)], axis=1)
    wavfile.write(os.path.join(ROOT, "sfx", name + ".wav"), RATE, (normalise(stereo, peak) * 32767).astype(np.int16))


if __name__ == "__main__":
    # Cue lengths fit the scene windows of film.script (start -> next cue).
    to_ogg("opening", opening(14.3))              # 0.0   -> 14.0
    to_ogg("strangers", strangers(59.8))          # 14.0  -> 73.5   nights 1 and 9
    to_ogg("friends", friends(62.3))              # 73.5  -> 135.5  night 30 to night 364
    to_ogg("empty", empty(58.8, 41.0))            # 135.5 -> 194.0  rises when she finds the note (~176)
    to_ogg("home", home(36.0, 24.2))              # 194.0 -> end    chord on the last title (~218)
    to_ambience("rain", rain(196.0), 0.5)
    to_ambience("drips", drips(36.0), 0.5)
    to_ambience("bus", bus(), 0.8)
    print("made music/*.ogg and sfx/*.wav")
