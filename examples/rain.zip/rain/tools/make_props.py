"""Builds every model in models/ for RAIN with Blender
(run inside Blender, or with the bpy module):  blender -b --python tools/make_props.py
Real-world sizes in metres, origin at the bottom centre (the grip for the umbrella),
front = -Y. Built from simple bevelled boxes, cylinders and spheres.
"""
import math
import os

import bpy
import bmesh  # after bpy: the bpy module provides it

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "models")


def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def mat(name, color, emit=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*color, 1)
    b.inputs["Roughness"].default_value = 0.8
    if emit:
        b.inputs["Emission Color"].default_value = (*color, 1)
        b.inputs["Emission Strength"].default_value = emit
    return m


def slab(name, outline, y0, y1, material):
    """A 2D outline [(x, z), …] (counter-clockwise, seen from the front) pushed from y0 to y1."""
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    front = [bm.verts.new((x, y0, z)) for x, z in outline]
    back = [bm.verts.new((x, y1, z)) for x, z in outline]
    bm.faces.new(front)
    bm.faces.new(list(reversed(back)))
    n = len(outline)
    for i in range(n):
        j = (i + 1) % n
        bm.faces.new([front[i], back[i], back[j], front[j]])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(obj)
    mesh.materials.append(material)
    return obj


def disc(name, radius, centre, y, material, verts=48):
    pts = [(centre[0] + radius * math.cos(a), centre[1] + radius * math.sin(a))
           for a in [i / verts * math.tau for i in range(verts)]]
    return slab(name, pts, y, y + 0.05, material)


def export(name):
    bpy.ops.export_scene.gltf(filepath=os.path.join(OUT, name + ".glb"), export_format="GLB")
    print("built", name)








def box(name, size, loc, material, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    o = bpy.context.object
    o.name = name
    o.scale = size
    bpy.ops.object.transform_apply(scale=True)
    if bevel:
        mod = o.modifiers.new("b", "BEVEL")
        mod.width = bevel
        mod.segments = 2
        bpy.ops.object.modifier_apply(modifier="b")
    o.data.materials.append(material)
    return o


def cyl(name, radius, depth, loc, material, rot=(0, 0, 0), verts=24):
    bpy.ops.mesh.primitive_cylinder_add(radius=radius, depth=depth, location=loc, rotation=rot, vertices=verts)
    o = bpy.context.object
    o.name = name
    o.data.materials.append(material)
    bpy.ops.object.shade_smooth()
    return o


def glass_mat(name, color, alpha):
    m = mat(name, color)
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Alpha"].default_value = alpha
    b.inputs["Roughness"].default_value = 0.05
    m.blend_method = "BLEND"
    return m


def shelter():
    """A city bus shelter, 3.4 m wide, front facing -Y. Its long bench is centred on the
    origin (seat 0.45 m up), so people sit on it; a glass back and sides, a roof with a
    light strip, a lit advert panel at one end and a route sign."""
    reset()
    frame = mat("frame", (0.16, 0.17, 0.19))
    frame.node_tree.nodes["Principled BSDF"].inputs["Metallic"].default_value = 0.7
    glass = glass_mat("glass", (0.6, 0.7, 0.75), 0.18)
    wood = mat("benchwood", (0.42, 0.28, 0.18))
    # Posts and roof.
    for x in (-1.7, 1.7):
        for y in (0.55, -0.55):
            box("post", (0.07, 0.07, 2.45), (x, y, 1.225), frame)
    box("roof", (3.6, 1.45, 0.08), (0, 0, 2.48), frame, 0.01)
    box("roofedge", (3.6, 0.06, 0.18), (0, -0.72, 2.42), mat("roofedge", (0.6, 0.12, 0.1)), 0.005)
    box("lightstrip", (3.0, 0.12, 0.02), (0, 0.0, 2.43), mat("strip", (1.0, 0.92, 0.75), emit=6.0))
    # Glass back and one side; the advert panel is the other side.
    box("back", (3.3, 0.02, 1.9), (0, 0.55, 1.3), glass)
    box("side", (0.02, 1.0, 1.9), (-1.7, 0.02, 1.3), glass)
    box("adframe", (0.12, 1.1, 2.0), (1.7, 0.0, 1.3), frame, 0.01)
    box("ad", (0.13, 0.95, 1.75), (1.7, 0.0, 1.3), mat("ad", (0.95, 0.72, 0.42), emit=0.9))
    box("adpic", (0.135, 0.7, 0.6), (1.7, 0.0, 1.55), mat("adpic", (0.25, 0.45, 0.6), emit=0.6))
    # Bench.
    box("seat", (2.9, 0.42, 0.05), (0, 0.18, 0.45), wood, 0.01)
    for x in (-1.3, 0, 1.3):
        box("leg", (0.05, 0.35, 0.43), (x, 0.2, 0.215), frame)
    # Route sign on a pole at the kerb end.
    box("pole", (0.06, 0.06, 2.7), (-2.1, -0.4, 1.35), frame)
    cyl("signdisc", 0.17, 0.03, (-2.1, -0.43, 2.55), mat("sign", (0.85, 0.2, 0.15), emit=0.4), rot=(math.pi / 2, 0, 0), verts=32)
    box("signboard", (0.5, 0.03, 0.55), (-2.1, -0.43, 1.95), mat("board", (0.95, 0.93, 0.85), emit=0.5))
    # A warm light under the roof.
    bpy.ops.object.light_add(type="POINT", location=(0, -0.1, 2.25))
    light = bpy.context.object
    light.data.energy = 220
    light.data.color = (1.0, 0.86, 0.66)
    light.data.shadow_soft_size = 0.4
    bpy.ops.export_scene.gltf(filepath=os.path.join(OUT, "shelter_bench.glb"), export_format="GLB", export_lights=True)
    print("built shelter_bench")


def umbrella(name, color):
    """An open umbrella. The origin is the grip (where the hand holds it); the canopy is
    a shallow dome 1.05 m across, 0.75-0.95 m above the grip."""
    reset()
    cloth = mat("cloth_" + name, color)
    metal = mat("shaft", (0.2, 0.2, 0.2))
    metal.node_tree.nodes["Principled BSDF"].inputs["Metallic"].default_value = 0.8
    cyl("shaft", 0.008, 0.98, (0, 0, 0.49), metal)
    bpy.ops.mesh.primitive_torus_add(major_radius=0.035, minor_radius=0.009, location=(0.035, 0, -0.0),
                                     rotation=(math.pi / 2, 0, 0))
    hook = bpy.context.object
    hook.data.materials.append(mat("grip", (0.12, 0.08, 0.06)))
    cyl("handle", 0.014, 0.12, (0, 0, 0.06), hook.data.materials[0])
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.53, location=(0, 0, 0.73), segments=8, ring_count=10)
    dome = bpy.context.object
    dome.scale = (1, 1, 0.42)
    bpy.ops.object.transform_apply(scale=True)
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="DESELECT")
    bpy.ops.object.mode_set(mode="OBJECT")
    for v in dome.data.vertices:
        v.select = v.co.z < 0.0
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.delete(type="VERT")
    bpy.ops.object.mode_set(mode="OBJECT")
    mod = dome.modifiers.new("s", "SOLIDIFY")
    mod.thickness = 0.01
    bpy.ops.object.modifier_apply(modifier="s")
    dome.data.materials.append(cloth)
    export(name)


def umbrella_closed():
    """The black umbrella closed and leaning against something (origin at its tip)."""
    reset()
    cloth = mat("cloth_closed", (0.05, 0.05, 0.06))
    bpy.ops.mesh.primitive_cone_add(radius1=0.006, radius2=0.05, depth=0.7, location=(0, 0, 0.45), vertices=8)
    o = bpy.context.object
    o.data.materials.append(cloth)
    cyl("tip", 0.006, 0.1, (0, 0, 0.05), mat("tipm", (0.3, 0.3, 0.3)))
    cyl("shaftc", 0.009, 0.12, (0, 0, 0.86), cloth)
    bpy.ops.mesh.primitive_torus_add(major_radius=0.035, minor_radius=0.01, location=(0.035, 0, 0.92), rotation=(math.pi / 2, 0, 0))
    bpy.context.object.data.materials.append(mat("gripc", (0.12, 0.08, 0.06)))
    for ob in bpy.context.scene.objects:
        ob.rotation_euler = (0, math.radians(-12), 0)
    export("umbrella_closed")


def bun():
    """A small paper bag of warm buns from the bakery."""
    reset()
    box("bag", (0.16, 0.1, 0.2), (0, 0, 0.1), mat("paper", (0.78, 0.62, 0.42)), 0.004)
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.055, location=(0.0, 0, 0.22))
    b = bpy.context.object
    b.scale = (1, 1, 0.7)
    b.data.materials.append(mat("bunm", (0.8, 0.5, 0.2)))
    export("bun_bag")


def shop_front():
    """A small corner bakery front for the building wall: a warm lit window, a door
    and a striped awning. 5 m wide; place it against a building."""
    reset()
    box("wall", (5.0, 0.2, 3.2), (0, 0.1, 1.6), mat("shopwall", (0.32, 0.22, 0.18)))
    box("window", (2.8, 0.05, 1.7), (-0.7, -0.02, 1.35), mat("shopwin", (1.0, 0.78, 0.48), emit=1.4))
    for x in (-2.1, -0.7, 0.7):
        box("mullion", (0.05, 0.06, 1.7), (x, -0.05, 1.35), mat("mull", (0.2, 0.15, 0.1)))
    box("door", (1.0, 0.05, 2.2), (1.6, -0.02, 1.1), mat("shopdoor", (0.9, 0.62, 0.35), emit=0.7))
    for i in range(10):
        box("stripe%d" % i, (0.5, 1.2, 0.04), (-2.25 + i * 0.5, -0.6, 2.75), mat("aw%d" % (i % 2), [(0.75, 0.2, 0.15), (0.95, 0.9, 0.82)][i % 2]))
    box("sign", (2.4, 0.06, 0.4), (-0.7, -0.03, 2.35), mat("shopsign", (0.95, 0.85, 0.6), emit=1.5))
    export("shop_front")


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    shelter()
    umbrella("umbrella_black", (0.05, 0.05, 0.06))
    umbrella("umbrella_yellow", (0.95, 0.75, 0.1))
    umbrella_closed()
    bun()
    shop_front()
