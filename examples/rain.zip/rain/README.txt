RAIN  (about 3 min 50 s)
An original Scene Builder short in realistic 3D.

Every night the 9:40 bus is late. Every night Dev - a baker on the night shift - is already
waiting under the shelter, and every night Mira - a nurse - runs in from the rain without an
umbrella. Night by night a stranger becomes a friend. Then, on night 365, he isn't there.

HOW TO WATCH
  Needs Scene Builder 1.12 or newer (Rain Street, umbrellas, hand-placed cameras).
  Script -> Open... -> rain.zip -> Build Film -> Watch.
  For the best look, set Render quality to High or Cinematic and export the video.

STRUCTURE (built so people watch to the end)
    0:00  Cold open    a closed umbrella on an empty bench: "Every night for a year, the
                       9:40 bus was late. And every night, a stranger was already there."
    0:14  Night 1      two strangers at opposite ends of the bench; silence; the bus
    0:50  Night 9      "From the bakery. Night shift. Leftovers." - "Thank you."
    1:14  Night 30     "Nurse. St. Mary's." - "Then you need this more than I do." - he walks
                       her to the bus under his umbrella
    1:48  Every night  nights 58, 121, 213 ("I bought my own." - "Now it'll never rain on us again.")
    2:16  Night 365    he isn't there. She waits. The bus comes and goes. 366. 367.
                       His umbrella on the bench, with a note: "I'm at St. Mary's. Your ward. Bed 4."
    3:14  Night 401    the rain has stopped. She holds her umbrella over him anyway.
                       "It's not raining." - "I know."   Be someone's umbrella.
  The night counter keeps a quiet clock running; the cold open asks a question the ending
  answers; the mid-film disappearance is the hook that holds the second half.

CAST
  Dev  = man in a dark blue coat and red scarf, with a black umbrella
  Mira = woman in a brown coat and cream scarf, later with a yellow umbrella

FILES
  film.script            the film (Rain Street, CAMERA: manual, hand-placed cameras)
  models/*.glb           bus shelter (with its own light), black and yellow umbrellas, closed
                         umbrella, bag of buns, bakery front (tools/make_props.py, Blender)
  music/*.ogg            opening, strangers, friends, empty, home - one raindrop figure throughout
  sfx/*.wav              rain (whole film), bus, drips (tools/make_audio.py)
  storyboard.png         frames from a test build

Every model, note and sound was made from scratch by the tools. Story and lines are original.
